require("./config")
const { smsg, getGroupAdmins, formatDate, getTime, isUrl, sleep, runtime, fetchJson, getBuffer, jsonformat, delay, generateProfilePicture, parseMention, getRandom, pickRandom, reSize } = require('./lib/myfunction');

const { 
    downloadContentFromMessage, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, generateWAMessageFromContent, 
    areJidsSameUser, WAMessageStatus, AuthenticationState, getContentType, useSingleFileAuthState, WAMessageProto, relayWAMessage, 
    Browsers, DisconnectReason, WASocket, fetchLatestBaileysVersion 
} = require('@whiskeysockets/baileys');

const axios = require('axios')
const os = require('os')
const fs = require('fs')
const DO_API_TOKEN = global.digitalocean_apikey
const crypto = require('crypto')
const {
    webp2mp4File,
    floNime
} = require('./lib/uploader')
const { pomfCDN } = require('./lib/uploader')
const ffstalk = require('./lib/ffstalk')
const mlstalk = require('./lib/mlstalk')
const { Client } = require('ssh2');
const { TelegraPh, UploadFileUgu } = require('./lib/Upload_Url');
const { mediafireDl } = require('./lib/mediafire.js')
const util = require('util')
const path = require('path')
const cron = require('node-cron')
const fetch = require('node-fetch')
const speed = require('performance-now')
const moment = require('moment-timezone')
const { spawn: spawn, exec } = require('child_process')
const { Primbon } = require('scrape-primbon')
const primbon = new Primbon()
const { performance } = require('perf_hooks')
const ytdl = require("ytdl-core")
const colors = require('@colors/colors/safe')
const chalk = require('chalk')
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const { toPTT, toAudio } = require("./lib/converter")
const { default: makeWaSocket, useMultiFileAuthState } = require('@whiskeysockets/baileys')
const pino = require('pino')
const time2 = require('pino')
const archiver = require('archiver')
//  Base
module.exports = async (Rulzx, m) => {
try {
const from = m.key.remoteJid
const quoted = m.quoted ? m.quoted : m
var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') && m.message.buttonsResponseMessage.selectedButtonId ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') && m.message.listResponseMessage.singleSelectreply.selectedRowId ? m.message.listResponseMessage.singleSelectreply.selectedRowId : (m.mtype == 'templateButtonreplyMessage') && m.message.templateButtonreplyMessage.selectedId ? m.message.templateButtonreplyMessage.selectedId : (m.mtype == 'interactiveResponseMessage') && JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectreply.selectedRowId || m.text) : ""
      var budy = (typeof m.text == 'string' ? m.text : '')
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const botNumber = await Rulzx.decodeJid(Rulzx.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = ["6281542692178@s.whatsapp.net", botNumber, ...global.ownNumb].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const mime = (quoted.msg || quoted).mimetype || quoted.mediaType || "";
const isMedia = /image|video|sticker|audio/.test(mime)
        const qmsg = (quoted.msg || quoted)
// Group
const groupMetadata = m.isGroup ? await Rulzx.groupMetadata(m.chat).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const isGroup = m.key.remoteJid.endsWith('@g.us')
const groupOwner = m.isGroup ? groupMetadata.owner : ''
const isGroupOwner = m.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false
const wib = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z")
const wita = moment(Date.now()).tz("Asia/Makassar").locale("id").format("HH:mm:ss z")
const fkontak = { key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': `Rulzx Store`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;RulzxBot,;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': { url: 'https://telegra.ph/file/a915fdf6f21ad99179f15.jpg' }}}}
//Public dan Self
if (!Rulzx.public) {
if (!isCreator && !m.key.fromMe) return
}

// Quoted
const { type } = m
const isImage = (type == 'imageMessage')
const isQuotedMsg = (type == 'extendedTextMessage')
const isQuotedImage = isQuotedMsg ? content.includes('imageMessage') ? true : false : false
const isVideo = (type == 'videoMessage')
const isQuotedVideo = isQuotedMsg ? content.includes('videoMessage') ? true : false : false
const isSticker = (type == 'stickerMessage')
const isQuotedSticker = isQuotedMsg ? content.includes('stickerMessage') ? true : false : false 
const isQuotedAudio = isQuotedMsg ? content.includes('audioMessage') ? true : false : false
 let m2 = "`"


try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let user = global.db.users[m.sender]
if (typeof user !== 'object') global.db.users[m.sender] = {}
if (user) {
if (!('daftar' in user)) user.daftar = false
if (!('nama' in user)) user.nama = `${pushname}`
if (!('saldo' in user)) user.saldo = `${toRupiah(cekSaldo(m.sender, db_saldo))}`
} else global.db.users[m.sender] = {
daftar: false,
nama: `${pushname}`,
saldo: `${toRupiah(cekSaldo(m.sender, db_saldo))}`,

}
} catch (err){
console.log(err)
}

// Console
if (isGroup && isCmd) {
console.log(colors.green.bold("[Group]") + " " + colors.brightCyan(time2,) + " " + colors.black.bgYellow(command) + " " + colors.green("from") + " " + colors.blue(groupName));
}

if (!isGroup && isCmd) {
console.log(colors.green.bold("[Private]") + " " + colors.brightCyan(time2,) + " " + colors.black.bgYellow(command) + " " + colors.green("from") + " " + colors.blue(pushname));
}


const fVerif = { key: {
    participant: '0@s.whatsapp.net',
    remoteJid: '0@s.whatsapp.net'
  },
  message: { conversation: `_Rulzx Terverifikasi Oleh WhatsApp_`}
}
const reply = async(teks) => 
      {
        Rulzx.sendMessage(
          from, 
            {text: 
              teks, 
                contextInfo: 
                  {
                    forwardingScore: 999,
                      isForwarded: true,
                forwardedNewsletterMessageInfo: 
              {
	        newsletterName: 'Rulzx - MD',
		  newsletterJid: "120363307170529595@g.us",
		}}},
      {quoted:fVerif}
    )
  }
const Reply = async(teks) => 
      {
        Rulzx.sendMessage(
          from, 
            {text: 
              teks, 
                contextInfo: 
                  {
                    forwardingScore: 999,
                      isForwarded: true,
                forwardedNewsletterMessageInfo: 
              {
	        newsletterName: 'Rulzx - MD',
		  newsletterJid: "120363307170529595@g.us",
		}}},
      {quoted:fVerif}
    )
  }
    

const tag = `@${m.sender.split('@')[0]}`
const totalFitur = () =>{
            var mytext = fs.readFileSync("./Rulzx.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
        

// Function to calculate profit
// Function to add a fixed profit amount to the price
async function countProfit(price) {
    const profitAmount = 1000; // Set the profit amount here
    return price + profitAmount; // Add the profit amount to the original price
}

switch(command) {
       case 'updatefile': {
    if (!isCreator) {
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Perintah ini hanya dapat digunakan oleh owner bot.',
        });
    }

    try {
        const senderNumber = m.sender;
        const date = new Date().toISOString();
        const senderName = senderNumber; // Bisa diubah jika bisa mendapatkan nama pengguna

        const newEntry = {
            nama: senderName,
            nomor: senderNumber,
            tanggal: date
        };

        // Konfigurasi GitHub
        const owner = global.githubOwner;
        const repo = global.githubRepo;
        const path = 'database.json';
        const branch = global.githubBranch || 'main';
        const githubToken = global.githubToken;

        const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${path}?ref=${branch}`;
        const headers = {
            'Content-Type': 'application/json',
            Authorization: `token ${githubToken}`,
            Accept: 'application/vnd.github.v3+json'
        };

        // Ambil data dari GitHub
        let response = await fetch(apiUrl, { headers });
        let sha = null;
        let currentData = { data: [] };

        if (response.ok) {
            const data = await response.json();
            sha = data.sha;
            const contentStr = Buffer.from(data.content, 'base64').toString('utf-8');
            try {
                currentData = JSON.parse(contentStr);
            } catch (err) {
                console.error('⚠️ File JSON rusak, membuat ulang...');
                currentData = { data: [] };
            }
        } else if (response.status === 404) {
            console.log('📁 File tidak ditemukan, membuat file baru...');
            currentData = { data: [] };
        } else {
            throw new Error(`Gagal mendapatkan file dari GitHub: ${response.statusText}`);
        }

        // Pastikan `currentData.data` adalah array
        if (!Array.isArray(currentData.data)) {
            currentData.data = [];
        }

        // **Langsung Tambahkan Data Baru (Tanpa Menghapus Data Lama)**
        currentData.data.push(newEntry);

        const updatedContent = JSON.stringify(currentData, null, 2);
        const base64Content = Buffer.from(updatedContent, 'utf-8').toString('base64');

        // Payload untuk update GitHub
        const payload = {
            message: `Tambah entri baru untuk ${senderName}`,
            committer: {
                name: global.githubCommitterName || 'WhatsApp Bot',
                email: global.githubCommitterEmail || 'bot@example.com'
            },
            content: base64Content,
            branch: branch
        };

        if (sha) {
            payload.sha = sha;
        }

        // Kirim perubahan ke GitHub
        response = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${path}`, {
            method: 'PUT',
            headers,
            body: JSON.stringify(payload)
        });

        const resultData = await response.json();
        console.log('🔍 Response dari GitHub:', resultData);

        if (!response.ok) {
            throw new Error(resultData.message || 'Gagal mengupdate file di GitHub.');
        }

        return Rulzx.sendMessage(m.chat, {
            text: `✅ Data baru berhasil ditambahkan ke GitHub!\n🔹 Commit: ${resultData.commit.message}`,
        });
    } catch (error) {
        console.error('❌ Error saat update file GitHub:', error);
        return Rulzx.sendMessage(m.chat, {
            text: `❌ Gagal mengupdate file GitHub.\n🛠 Error: ${error.message}`,
        });
    }
}
break

case 'backup': {
    if (!isCreator) {
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Perintah ini hanya dapat digunakan oleh owner bot.',
        });
    }

    try {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const zipFileName = `backup_${wib}.zip`;
        const zipFilePath = path.join(__dirname, zipFileName);

        // Membuat file ZIP
        const output = fs.createWriteStream(zipFilePath);
        const archive = archiver('zip', { zlib: { level: 9 } });

        output.on('close', async () => {
            console.log(`✅ Arsip ZIP berhasil dibuat (${archive.pointer()} bytes)`);

            // Konfigurasi GitHub
            const owner = global.githubOwner;
            const repo = global.githubRepo;
            const pathInRepo = `backups/${zipFileName}`;
            const branch = global.githubBranch || 'main';
            const githubToken = global.githubToken;

            const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${pathInRepo}`;
            const headers = {
                'Content-Type': 'application/json',
                Authorization: `token ${githubToken}`,
                Accept: 'application/vnd.github.v3+json'
            };

            // Baca file ZIP dan encode ke base64
            const fileData = fs.readFileSync(zipFilePath);
            const base64Content = fileData.toString('base64');

            // Persiapkan payload untuk GitHub
            const payload = {
                message: `Backup otomatis: ${zipFileName}`,
                committer: {
                    name: global.githubCommitterName || 'WhatsApp Bot',
                    email: global.githubCommitterEmail || 'bot@example.com'
                },
                content: base64Content,
                branch: branch
            };

            // Unggah ke GitHub
            const response = await fetch(apiUrl, {
                method: 'PUT',
                headers,
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Gagal mengunggah backup ke GitHub.');
            }

            // Hapus file lokal setelah berhasil diunggah
            fs.unlinkSync(zipFilePath);

            return Rulzx.sendMessage(m.chat, {
                text: `✅ Backup berhasil diunggah ke GitHub!\n🔹 File: ${zipFileName}`,
            });
        });

        archive.on('error', (err) => {
            throw err;
        });

        archive.pipe(output);

        // Tambahkan folder yang ingin dibackup
        const foldersToBackup = ['database', 'lib', 'Rulzxcsesion', 'srv'];
        foldersToBackup.forEach(folder => {
            const folderPath = path.join(__dirname, folder);
            if (fs.existsSync(folderPath)) {
                archive.directory(folderPath, folder);
            }
        });

        // Tambahkan file yang ingin dibackup
        const filesToBackup = [
            'config.js',
            'index.js',
            'package.json',
            'package-lock.json',
            'Rulzxcx.js'
        ];
        filesToBackup.forEach(file => {
            const filePath = path.join(__dirname, file);
            if (fs.existsSync(filePath)) {
                archive.file(filePath, { name: file });
            }
        });

        archive.finalize();
    } catch (error) {
        console.error('❌ Error saat melakukan backup:', error);
        return Rulzx.sendMessage(m.chat, {
            text: `❌ Gagal melakukan backup.\n🛠 Error: ${error.message}`,
        });
    }
}
break
        case 'gpt4': { 
  if (!text) return m.reply('Hai, apa yang ingin saya bantu?')
async function openai(text, logic) { // Membuat fungsi openai untuk dipanggil
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,  // Sesuaikan token limit jika diperlukan
            "tokenLimit": 8000,  // Sesuaikan token limit untuk model GPT-4
            "completionTokenLimit": 5000,  // Sesuaikan jika diperlukan
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let rulzai = await openai(text, "nama mu adalah Furina, kamu adalah asisten kecerdasan buatan yang sering membantu orang lain jika ada yang ditanyakan")
m.reply(rulzai)
}
        break
case 'rulzx': {
  if (!text) return m.reply(`╭───⟪ 🌟 INFORMATION BOT 🌟 ⟫───╮
┃  
┣━━━ 🖥️ VPS MENU ━━━
┃   ∘ ✧ .listvps
┃   ∘ ✧ .delvps
┃   ∘ ✧ .monitoring
┃   ∘ ✧ .billing
┃  
╰─────────────────────────╯
`)
}
break
case "ram1":
case "ram2":
case "ram4":
case "ram8":
case "ram16": {
    if (!isCreator) return Reply("Khusus Owner");
    if (!text) return m.reply(`Example : *.${command}* hostname`);

    await sleep(1000);
    
    let sizeMap = {
        ram1: "s-1vcpu-1gb",
        ram2: "s-1vcpu-2gb",
        ram4: "s-2vcpu-4gb",
        ram8: "s-4vcpu-8gb",
        ram16: "s-4vcpu-16gb-amd",
    };

    let size = sizeMap[command];
    let region = "sgp1";
    let hostname = text.toLowerCase();
    if (!hostname) return m.reply(`Example : *.${command}* hostname`);

    function generateRandomPassword() {
        const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*";
        const length = 10;
        let password = "";
        for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            password += characters[randomIndex];
        }
        return password;
    }

    try {
        let password = generateRandomPassword();
        let dropletData = {
            name: hostname,
            region: region,
            size: size,
            image: "ubuntu-20-04-x64",
            backups: false,
            ipv6: true,
            tags: ["T"],
            user_data: `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`,
        };

        let response = await fetch("https://api.digitalocean.com/v2/droplets", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.digitalocean_apikey,
            },
            body: JSON.stringify(dropletData),
        });

        let responseData = await response.json();
        if (!response.ok) throw new Error(`Gagal membuat VPS: ${responseData.message}`);

        let dropletId = responseData.droplet.id;

        await m.reply(`⚡ ᴍᴇᴍᴘʀᴏsᴇs ᴘᴇᴍʙᴜᴀᴛᴀɴ ᴠᴘꜱ... ⚡\n🔧 sᴇᴅᴀɴɢ ᴍᴇᴍʙᴜᴀᴛ ᴠᴘꜱ ᴅᴀɴ ᴘᴀɴᴇʟ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ\n🕐 ᴍᴏɴɪᴛᴏʀ ᴅᴀɴ ᴏᴘᴇʀᴀsɪ ᴍᴇɴɢᴇɴᴀʟᴀ ᴅɪᴘᴇʀɪɴᴛᴀʜᴋᴀɴ...`);
        
        await sleep(25000);

        let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.digitalocean_apikey,
            },
        });

        let dropletInfo = await dropletResponse.json();
        let ipVPS = dropletInfo.droplet.networks.v4[0]?.ip_address || "Tidak ada IP tersedia";

        await m.reply(`✅ *VPS Berhasil Dibuat!* ✅\n\n📌 *Nama VPS:* ${hostname}\n🆔 *ID VPS:* ${dropletId}\n🌐 *IP VPS:* ${ipVPS}\n🔑 *Password:* ${password}\n\n🔄 *Gunakan SSH untuk login:*
\`\`\`
ssh root@${ipVPS}
Password: ${password}
\`\`\`
`);

    } catch (error) {
        console.error(error);
        await m.reply(`❌ Terjadi kesalahan: ${error.message}`);
    }
}
case "ram1v2":
case "ram2v2":
case "ram4v2":
case "ram8v2":
case "ram16v2": {
    if (!isCreator) return Reply("Khusus Owner");
    if (!text) return m.reply(`Example : *.${command}* hostname`);

    await sleep(1000);
    
    let sizeMap = {
        ram1: "s-1vcpu-1gb",
        ram2: "s-1vcpu-2gb",
        ram4: "s-2vcpu-4gb",
        ram8: "s-4vcpu-8gb",
        ram16: "s-4vcpu-16gb-amd",
    };

    let size = sizeMap[command];
    let region = "sgp1";
    let hostname = text.toLowerCase();
    if (!hostname) return m.reply(`Example : *.${command}* hostname`);

    function generateRandomPassword() {
        const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*";
        const length = 10;
        let password = "";
        for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            password += characters[randomIndex];
        }
        return password;
    }

    try {
        let password = generateRandomPassword();
        let dropletData = {
            name: hostname,
            region: region,
            size: size,
            image: "ubuntu-20-04-x64",
            backups: false,
            ipv6: true,
            tags: ["T"],
            user_data: `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`,
        };

        let response = await fetch("https://api.digitalocean.com/v2/droplets", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.digitalocean_apikeyv2,
            },
            body: JSON.stringify(dropletData),
        });

        let responseData = await response.json();
        if (!response.ok) throw new Error(`Gagal membuat VPS: ${responseData.message}`);

        let dropletId = responseData.droplet.id;

        await m.reply(`⚡ ᴍᴇᴍᴘʀᴏsᴇs ᴘᴇᴍʙᴜᴀᴛᴀɴ ᴠᴘꜱ... ⚡\n🔧 sᴇᴅᴀɴɢ ᴍᴇᴍʙᴜᴀᴛ ᴠᴘꜱ ᴅᴀɴ ᴘᴀɴᴇʟ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ\n🕐 ᴍᴏɴɪᴛᴏʀ ᴅᴀɴ ᴏᴘᴇʀᴀsɪ ᴍᴇɴɢᴇɴᴀʟᴀ ᴅɪᴘᴇʀɪɴᴛᴀʜᴋᴀɴ...`);
        
        await sleep(25000);

        let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.digitalocean_apikeyv2,
            },
        });

        let dropletInfo = await dropletResponse.json();
        let ipVPS = dropletInfo.droplet.networks.v4[0]?.ip_address || "Tidak ada IP tersedia";

        await m.reply(`✅ *VPS Berhasil Dibuat!* ✅\n\n📌 *Nama VPS:* ${hostname}\n🆔 *ID VPS:* ${dropletId}\n🌐 *IP VPS:* ${ipVPS}\n🔑 *Password:* ${password}\n\n🔄 *Gunakan SSH untuk login:*
\`\`\`
ssh root@${ipVPS}
Password: ${password}
\`\`\`
`);

    } catch (error) {
        console.error(error);
        await m.reply(`❌ Terjadi kesalahan: ${error.message}`);
    }
}


case 'delallusr': {
    try {
        if (!isCreator) return m.reply("❌ Anda tidak memiliki izin untuk menggunakan perintah ini.");

        const panelUrl = `${global.domain}/api/application/users`;

        const usersResponse = await fetch(panelUrl, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${global.apikey}`,
            },
        });

        if (!usersResponse.ok) {
            const errorText = await usersResponse.text();
            console.error('Gagal mengambil daftar user:', errorText);
            return m.reply(`❌ Gagal mengambil daftar user. Error: ${errorText}`);
        }

        const usersData = await usersResponse.json();
        const usersToDelete = [];

        // Filter user (exclude admin dan yang memiliki server)
        for (const user of usersData.data) {
            const userId = user.attributes.id;
            const isAdmin = user.attributes.root_admin;

            try {
                // Periksa apakah user memiliki server
                const userServersResponse = await fetch(`${panelUrl}/${userId}/servers`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${global.apikey}`,
                    },
                });

                if (userServersResponse.status === 404) {
                    console.warn(`User ID ${userId} tidak ditemukan di sistem.`);
                    continue; // Lanjutkan ke user berikutnya
                }

                if (!userServersResponse.ok) {
                    throw new Error(`HTTP Status ${userServersResponse.status}`);
                }

                const userServers = await userServersResponse.json();
                if (!isAdmin && userServers.data.length === 0) {
                    usersToDelete.push(userId);
                }
            } catch (err) {
                console.error(`Gagal memeriksa server untuk user ID ${userId}:`, err);
            }
        }

        for (let i = 0; i < usersToDelete.length; i++) {
            const userId = usersToDelete[i];
            console.log(`Menghapus user ID: ${userId}`);

            const deleteResponse = await fetch(`${panelUrl}/${userId}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${global.apikey}`,
                },
            });

            const deleteResponseText = await deleteResponse.text();
            console.log(`Response untuk user ID ${userId}:`, deleteResponseText);

            if (!deleteResponse.ok) {
                console.error(`Gagal menghapus user ID ${userId}: ${deleteResponseText || 'Kesalahan tidak diketahui.'}`);
            }

            await new Promise((resolve) => setTimeout(resolve, 1)); // Jeda antar penghapusan
        }

        return Rulzx.sendMessage(m.chat, {
            text: `✅ Semua user tanpa server dan bukan admin berhasil diproses untuk dihapus.`,
        });
    } catch (error) {
        console.error('Error saat menghapus user:', error);
        return Rulzx.sendMessage(m.chat, {
            text: `❌ Gagal menghapus user. Error: ${error.message || 'Kesalahan tidak diketahui.'}`,
        });
    }
}
break
case "brat": {

if (!text) return m.reply('teksnya')

let res = await getBuffer(`https://api.zenkey.my.id/api/maker/brat?text=${text}&apikey=zenkey`)

await Rulzx.sendMessage(m.chat, { sticker: { quoted: m }

}
                        ) }
        
case 'domain': {
  if (!text) return m.reply(`╭───⟪ 🌟 INFORMATION DOMAIN 🌟 ⟫───╮
┃  
┣━━━ DOMAIN MENU ━━━
┃   ∘ ✧ .domain1 alertdata.me
┃   ∘ ✧ .domain2 webservers.software
┃   ∘ ✧ .domain3 rulzcloud.systems
╰─────────────────────────╯
`)
}
break
case 'rank': {
  if (!text) return m.reply(`List Rank Server Futan :
VIP | Rp15.000

➤ Rank Permissions:

    3x Limit Claim
    5000 Limit Block
    5x Sethome

➤ Fitur Eksklusif:

    Akses ke perintah:
        /clan create
        /repair
        /food
        /heal
        /kit vip
    Bonus Money: Rp25.000

MVP | Rp35.000

➤ Rank Permissions:

    5x Limit Claim
    8000 Limit Block
    10x Sethome

➤ Fitur Eksklusif:

    Akses ke perintah:
        /ec (Enderchest)
        /feed
        /nick
        /kit mvp
    Termasuk semua fitur VIP
    Bonus Money: Rp40.000

Elite | Rp50.000

➤ Rank Permissions:

    8x Limit Claim
    10.000 Limit Block
    15x Sethome

➤ Fitur Eksklusif:

    Akses ke perintah:
        /ec (Enderchest)
        /fly
        /nick
        /repair
        /feed
        /kit elite
    Termasuk semua fitur MVP
    Bonus Money: Rp70.000

Legend | Rp90.000

➤ Rank Permissions:

    10x Limit Claim
    20.000 Limit Block
    25x Sethome

➤ Fitur Eksklusif:

    Akses ke perintah:
        /ec (Enderchest)
        /fly
        /nick
        /repair
        /kit legend
    Termasuk semua fitur Elite
    Bonus Money: Rp250.000

Sultan | Rp120.000

➤ Rank Permissions:

    20x Limit Claim
    30.000 Limit Block
    50x Sethome

➤ Fitur Eksklusif:

    Akses ke perintah:
        /ec (Enderchest)
        /beezooka
        /feed
        /fly
        /nick
        /repair
        /heal
        /kit sultan
    Termasuk semua fitur Legend
    Bonus Money: Rp350.000

Supreme | Rp150.000

➤ Rank Permissions:

    ∞ Limit Claim
    ∞ Limit Block
    999x Sethome

➤ Fitur Eksklusif:

    Akses ke perintah:
        /ec (Enderchest)
        /feed
        /fly
        /repair
        /nick
        /heal
        /craft
        /head
        /beezooka
        /kit supreme
    Termasuk semua fitur Sultan
    Bonus Money: Rp700.000`)
}
break
case 'listsrv': {
    if (!isCreator) return m.reply("Hanya pemilik yang dapat melakukan ini.");

    try {
        const panelUrl = `${global.domain}/api/application/servers`; // Ganti dengan URL API yang benar untuk mendapatkan daftar server

        // Melakukan GET untuk mendapatkan daftar server
        const response = await fetch(panelUrl, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${global.apikey}`, // Menambahkan Bearer token untuk autentikasi
            },
        });

        if (!response.ok) {
            const errorData = await response.text(); // Ambil respons sebagai teks
            throw new Error(`Gagal mendapatkan daftar server. Error: ${errorData || 'Kesalahan tidak diketahui.'}`);
        }

        const servers = await response.json(); // Ambil daftar server
        if (servers.length === 0) {
            return Rulzx.sendMessage(m.chat, {
                text: "Tidak ada server yang ditemukan.",
            });
        }

        // Membuat pesan untuk daftar server
        let serverListMessage = "Daftar Server:\n";
        servers.forEach((server, index) => {
            serverListMessage += `${index + 1}. ID: ${server.id}, Nama: ${server.name}\n`; // Sesuaikan dengan atribut yang ada
        });

        // Mengirimkan daftar server ke pengguna
        return Rulzx.sendMessage(m.chat, {
            text: serverListMessage,
        });
    } catch (error) {
        console.error('Error saat mendapatkan daftar server Pterodactyl:', error);
        return Rulzx.sendMessage(m.chat, {
            text: `❌ Gagal mendapatkan daftar server. Error: ${error.message || 'Kesalahan tidak diketahui.'}`,
        });
    }
}
break
case 'menu': {
  if (!text) return m.reply(`Maaf, Menu Telah Disembunyikan`)
}
break
case 'delallsrv': {
    if (!isCreator) return m.reply("Hapus Aja sendiri");

    try {
        const panelUrl = `${global.domain}/api/application/servers`;

        // Loop untuk menghapus server ID dari 1 hingga 500
        for (let serverId = 1; serverId <= 500; serverId++) {
            console.log(`Menghapus server ID: ${serverId}`);
            const deleteResponse = await fetch(`${panelUrl}/${serverId}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${global.apikey}`,
                },
            });

            const deleteResponseText = await deleteResponse.text();
            console.log(`Response untuk server ID ${serverId}:`, deleteResponseText);

            if (!deleteResponse.ok) {
                console.error(`Gagal menghapus server ID ${serverId}: ${deleteResponseText || 'Kesalahan tidak diketahui.'}`);
            }
        }

        return Rulzx.sendMessage(m.chat, {
            text: `✅ Semua server dengan ID 1-500 berhasil diproses untuk dihapus dari panel Pterodactyl.`,
        });
    } catch (error) {
        console.error('Error saat menghapus server ID 1-500:', error);
        return Rulzx.sendMessage(m.chat, {
            text: `❌ Gagal menghapus server ID 1-500. Error: ${error.message || 'Kesalahan tidak diketahui.'}`,
        });
    }
}
break
case 'delsrv': {
    if (!isCreator) return m.reply("Mau hapus apa?");
    try {
        const args = text.split(" ");
        const idserver = args[0];

        if (!idserver) {
            return m.reply("ID server tidak ditemukan. Harap masukkan ID server yang valid.");
        }

        const panelUrl = `${global.domain}/api/application/servers/${idserver}`; // Ganti dengan URL API yang benar

        // Pertama, kita lakukan GET untuk memastikan server ada
        const checkResponse = await fetch(panelUrl, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${global.apikey}`, // Menambahkan Bearer token untuk autentikasi
            },
        });

        if (!checkResponse.ok) {
            const checkErrorData = await checkResponse.text(); // Ambil respons sebagai teks
            throw new Error(`Server dengan ID *${idserver}* tidak ditemukan. Error: ${checkErrorData || 'Kesalahan tidak diketahui.'}`);
        }

        // Jika server ada, lanjutkan dengan DELETE
        const deleteResponse = await fetch(panelUrl, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${global.apikey}`,
            },
        });

        const deleteResponseText = await deleteResponse.text(); // Ambil respons sebagai teks
        console.log("Raw response from API (hapus):", deleteResponseText); // Log respons mentah

        if (!deleteResponse.ok) {
            throw new Error(`Gagal menghapus server: ${deleteResponseText || 'Kesalahan tidak diketahui.'}`);
        }

        // Jika berhasil menghapus server
        return Rulzx.sendMessage(m.chat, {
            text: `✅ Server dengan ID *${idserver}* berhasil dihapus dari panel Pterodactyl.`,
        });
    } catch (error) {
        console.error('Error saat menghapus server Pterodactyl:', error);
        return Rulzx.sendMessage(m.chat, {
            text: `❌ Gagal menghapus server. Error: ${error.message || 'Kesalahan tidak diketahui.'}`,
        });
    }
}
break
case "installtemabilling": case "itb": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split(",")) return m.reply("ipvps,pwvps")
let vii = text.split(",")
if (vii.length < 2) return m.reply("ipvps,pwvps")
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = 'bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)'
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install tema billing pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install tema billing pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('skyzodev\n') // Key Token : skyzodev
stream.write('1\n')
stream.write('2\n')
stream.write('yes\n')
stream.write('x\n')
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
case "r1":
case "r2":
case "r4":
case "r8":
case "r16": {
    if (!isCreator) return Reply("Khusus Owner");
    if (!text) return m.reply(`Example : *.${command}* hostname`);

    await sleep(1000);
    let sizeMap = {
        r1: "s-1vcpu-1gb",
        r2: "s-1vcpu-2gb",
        r4: "s-2vcpu-4gb",
        r8: "s-4vcpu-8gb",
        r16: "s-4vcpu-16gb-amd",
    };

    let size = sizeMap[command];
    let region = "sgp1";
    let hostname = text.toLowerCase();
    if (!hostname) return m.reply(`Example : *.${command}* hostname`);

    function generateRandomPassword() {
        const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*";
        const length = 10;
        let password = "";
        for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            password += characters[randomIndex];
        }
        return password;
    }

    try {
        let dropletData = {
            name: hostname,
            region: region,
            size: size,
            image: "ubuntu-20-04-x64",
            backups: false,
            ipv6: true,
            tags: ["T"],
        };

        const password = generateRandomPassword();
        dropletData.user_data = `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`;

        let response = await fetch("https://api.digitalocean.com/v2/droplets", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.digitalocean_apikey,
            },
            body: JSON.stringify(dropletData),
        });

        let responseData = await response.json();
        if (!response.ok) throw new Error(`Gagal membuat VPS: ${responseData.message}`);

        let dropletId = responseData.droplet.id;
        await m.reply(`⚡ ᴍᴇᴍᴘʀᴏsᴇs ᴘᴇᴍʙᴜᴀᴛᴀɴ ᴠᴘꜱ... ⚡
🔧 sᴇᴅᴀɴɢ ᴍᴇᴍʙᴜᴀᴛ ᴠᴘꜱ ᴅᴀɴ ᴘᴀɴᴇʟ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ
🕐 ᴍᴏɴɪᴛᴏʀ ᴅᴀɴ ᴏᴘᴇʀᴀsɪ ᴍᴇɴɢᴇɴᴀʟᴀ ᴅɪᴘᴇʀɪɴᴛᴀʜᴋᴀɴ...`);
        await sleep(130000);

        let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.digitalocean_apikey,
            },
        });

        let dropletInfo = await dropletResponse.json();
        let ipVPS = dropletInfo.droplet.networks.v4[0]?.ip_address || "Tidak ada IP tersedia";

        let domain = `${hostname}.rulzcloud.systems`;
        let domainNode = `${hostname}-node.rulzcloud.systems`;
        let zoneId = "09b85878919f7a9d75c765fc6ba436fc";
        let apiToken = "8r-j-ROIKnQLhhkdrwwtv2d2tT2sSlWsqUQIhsKr";

        async function createDNSRecord(name) {
            let dnsResponse = await fetch(`https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`, {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${apiToken}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    type: "A",
                    name: name,
                    content: ipVPS,
                    ttl: 120,
                    proxied: false,
                }),
            });
            let dnsData = await dnsResponse.json();
            if (!dnsData.success) throw new Error(`Gagal membuat DNS: ${dnsData.errors}`);
        }

 await createDNSRecord(domain);
        await createDNSRecord(domainNode);

        let connSettings = {
            host: ipVPS,
            port: 22,
            username: "root",
            password: password,
        };

        const commandPanel = "bash <(curl -s https://pterodactyl-installer.se)";
        const commandWings = "bash <(curl -s https://pterodactyl-installer.se)";
        const conn = new Client();

        conn.on("ready", () => {
            conn.exec(commandPanel, (err, stream) => {
                if (err) throw err;

                stream.on('data', (data) => {
                    if (data.toString().includes('Input')) {
                        stream.write('0\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('1248\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('Asia/Jakarta\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('admin@gmail.com\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('admin@gmail.com\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('admin\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('adm\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('adm\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('ByRulz1243\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write(`${domain}\n`);
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('y\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('y\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('y\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('y\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('yes\n');
                    }
                    if (data.toString().includes('Please read the Terms of Service')) {
                        stream.write('A\n');
                    }
                    if (data.toString().includes('Please read the Terms of Service')) {
                        stream.write('Y\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('1\n');
                    }
                    console.log('STDOUT Panel: ' + data);
                }).on('close', () => {
                    m.reply(`🎉 **ʏᴇᴀʏʏ! ᴘᴀɴᴇʟ sᴜᴅᴀʜ ᴛᴇʀɪɴsᴛᴀʟʟ!**  
🚀 Lanjutkan proses dengan mengatur *Wings* agar server siap digunakan`);

                    // Instal Wings pertama
                    conn.exec(commandWings, (err, stream) => {
                        if (err) throw err;

                        stream.on('data', (data) => {
                            if (data.toString().includes('Input')) {
                                stream.write('1\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write(`${domain}\n`);
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('user\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('1248\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write(`${domainNode}\n`);
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('admin@gmail.com\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            console.log('STDOUT Wings: ' + data);
                        }).on('close', () => {
                            m.reply(`🎉 **ʏᴇᴀʏʏ! ᴡɪɴɢs sᴜᴅᴀʜ ᴛᴇʀɪɴsᴛᴀʟʟ!**  
💾 Sedang memproses **pengambilan data Panel** untuk melengkapi konfigurasi server-mu.  

🛠️ **Apa yang perlu dilakukan selanjutnya?**  
✨ Tunggu sebentar, proses akan selesai dalam waktu singkat.  
✨ Data seperti username, password, domain, dan lainnya akan segera tersedia.  

🚀 Setelah proses selesai, VPS-mu akan siap digunakan untuk kebutuhanmu!  
`);
                            
                            // Instal Wings kedua
                            instalWings();
                        });
                    });
                });
            });
        }).connect(connSettings);

        async function instalWings() {
            conn.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', (err, stream) => {
                if (err) throw err;
                stream.on('close', async (code, signal) => {
                    let teks = `
🎉 ʙᴇʀɪᴋᴜᴛ ᴅᴇᴛᴀɪʟ ᴀᴋᴜɴ ᴘᴀɴᴇʟ ᴅᴀɴ ᴠᴘꜱ 🎉

🔐 ᴘᴀɴᴇʟ ᴀᴋᴜɴ
• ᴜꜱᴇʀᴘᴀɴᴇʟ: admin
• ᴘᴡᴘᴀɴᴇʟ: ByRulz1243
• ᴅᴏᴍᴀɪɴ: ${domain}

🌐 ᴅᴇᴛᴀɪʟ ᴠᴘꜱ
• ɪᴅ ᴠᴘꜱ: ${dropletId}
• ɪᴘ ᴠᴘꜱ: ${ipVPS}
• ᴘᴀꜱꜱᴡᴏʀᴅ ᴠᴘꜱ: ${password}
• ʀᴇɢɪᴏɴ: 🇸🇬 ꜱɪɴɢᴀᴘᴏʀᴇ
• ᴜꜱᴇʀ ᴠᴘꜱ: ʀᴏᴏᴛ
• ᴏꜱ: ᴜʙᴜɴᴛᴜ 22.04

💡 ɴᴏᴛᴇ:
ꜱɪʟᴀᴋᴀɴ ᴄᴀᴛᴀᴛ ᴅᴇᴛᴀɪʟ ɪɴɪ ᴅᴇɴɢᴀɴ ʙᴀɪᴋ ᴅᴀɴ ɢᴜɴᴀᴋᴀɴ ꜱᴇꜱᴜᴀɪ ᴋᴇʙᴜᴛᴜʜᴀɴ. ᴊɪᴋᴀ ᴀᴅᴀ ᴋᴇɴᴅᴀʟᴀ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴜᴘᴘᴏʀᴛ!

🔥 ᴋᴇᴘᴜᴛᴜꜱᴀɴ ʙᴇʀᴀᴡᴀʟ ᴅᴀʀɪ ꜱɪɴɪ! 🔥`
                    await Rulzx.sendMessage(m.chat, { text: teks });
                }).on('data', (data) => {
                    console.log(data.toString());
                    if (data.toString().includes("Masukkan nama lokasi: ")) {
                        stream.write('Singapore\n');
                    }
                    if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
                        stream.write('Singapore Location\n');
                    }
                    if (data.toString().includes("Masukkan domain: ")) {
                        stream.write(`${domainNode}\n`);
                    }
                    if (data.toString().includes("Masukkan nama node: ")) {
                        stream.write('Rulzx Node\n');
                    }
                    if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
                        stream.write('32000\n');
                    }
                    if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
                        stream.write('32000\n');
                    }
                    if (data.toString().includes("Masukkan Locid: ")) {
                        stream.write('1\n');
                    }
                }).stderr.on('data', (data) => {
                    console.log('Stderr: ' + data);
                });
            });
        }
    } catch (error) {
        console.error(error);
        await m.reply(`Terjadi kesalahan: ${error.message}`);
    }
}
break
case "r1v2":
case "r2v2":
case "r4v2":
case "r8v2":
case "r16v2": {
    if (!isCreator) return Reply("Khusus Owner");
    if (!text) return m.reply(`Example : *.${command}* hostname`);

    await sleep(1000);
    let sizeMap = {
        r1v2: "s-1vcpu-1gb",
        r2v2: "s-1vcpu-2gb",
        r4v2: "s-2vcpu-4gb",
        r8v2: "s-4vcpu-8gb",
        r16v2: "s-4vcpu-16gb-amd",
    };

    let size = sizeMap[command];
    let region = "sgp1";
    let hostname = text.toLowerCase();
    if (!hostname) return m.reply(`Example : *.${command}* hostname`);

    function generateRandomPassword() {
        const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*";
        const length = 10;
        let password = "";
        for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            password += characters[randomIndex];
        }
        return password;
    }

    try {
        let dropletData = {
            name: hostname,
            region: region,
            size: size,
            image: "ubuntu-20-04-x64",
            backups: false,
            ipv6: true,
            tags: ["T"],
        };

        const password = generateRandomPassword();
        dropletData.user_data = `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`;

        let response = await fetch("https://api.digitalocean.com/v2/droplets", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.digitalocean_apikeyv2,
            },
            body: JSON.stringify(dropletData),
        });

        let responseData = await response.json();
        if (!response.ok) throw new Error(`Gagal membuat VPS: ${responseData.message}`);

        let dropletId = responseData.droplet.id;
        await m.reply(`⚡ ᴍᴇᴍᴘʀᴏsᴇs ᴘᴇᴍʙᴜᴀᴛᴀɴ ᴠᴘꜱ... ⚡
🔧 sᴇᴅᴀɴɢ ᴍᴇᴍʙᴜᴀᴛ ᴠᴘꜱ ᴅᴀɴ ᴘᴀɴᴇʟ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ
🕐 ᴍᴏɴɪᴛᴏʀ ᴅᴀɴ ᴏᴘᴇʀᴀsɪ ᴍᴇɴɢᴇɴᴀʟᴀ ᴅɪᴘᴇʀɪɴᴛᴀʜᴋᴀɴ...`);
        await sleep(130000);

        let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.digitalocean_apikeyv2,
            },
        });

        let dropletInfo = await dropletResponse.json();
        let ipVPS = dropletInfo.droplet.networks.v4[0]?.ip_address || "Tidak ada IP tersedia";

        let domain = `${hostname}.rulzcloud.systems`;
        let domainNode = `${hostname}-node.rulzcloud.systems`;
        let zoneId = "09b85878919f7a9d75c765fc6ba436fc";
        let apiToken = "8r-j-ROIKnQLhhkdrwwtv2d2tT2sSlWsqUQIhsKr";

        async function createDNSRecord(name) {
            let dnsResponse = await fetch(`https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`, {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${apiToken}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    type: "A",
                    name: name,
                    content: ipVPS,
                    ttl: 120,
                    proxied: false,
                }),
            });
            let dnsData = await dnsResponse.json();
            if (!dnsData.success) throw new Error(`Gagal membuat DNS: ${dnsData.errors}`);
        }

 await createDNSRecord(domain);
        await createDNSRecord(domainNode);

        let connSettings = {
            host: ipVPS,
            port: 22,
            username: "root",
            password: password,
        };

        const commandPanel = "bash <(curl -s https://pterodactyl-installer.se)";
        const commandWings = "bash <(curl -s https://pterodactyl-installer.se)";
        const conn = new Client();

        conn.on("ready", () => {
            conn.exec(commandPanel, (err, stream) => {
                if (err) throw err;

                stream.on('data', (data) => {
                    if (data.toString().includes('Input')) {
                        stream.write('0\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('1248\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('Asia/Jakarta\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('admin@gmail.com\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('admin@gmail.com\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('admin\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('adm\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('adm\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('ByRulz1243\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write(`${domain}\n`);
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('y\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('y\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('y\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('y\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('yes\n');
                    }
                    if (data.toString().includes('Please read the Terms of Service')) {
                        stream.write('A\n');
                    }
                    if (data.toString().includes('Please read the Terms of Service')) {
                        stream.write('Y\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('\n');
                    }
                    if (data.toString().includes('Input')) {
                        stream.write('1\n');
                    }
                    console.log('STDOUT Panel: ' + data);
                }).on('close', () => {
                    m.reply(`🎉 **ʏᴇᴀʏʏ! ᴘᴀɴᴇʟ sᴜᴅᴀʜ ᴛᴇʀɪɴsᴛᴀʟʟ!**  
🚀 Lanjutkan proses dengan mengatur *Wings* agar server siap digunakan`);

                    // Instal Wings pertama
                    conn.exec(commandWings, (err, stream) => {
                        if (err) throw err;

                        stream.on('data', (data) => {
                            if (data.toString().includes('Input')) {
                                stream.write('1\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write(`${domain}\n`);
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('user\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('1248\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write(`${domainNode}\n`);
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('admin@gmail.com\n');
                            }
                            if (data.toString().includes('Input')) {
                                stream.write('y\n');
                            }
                            console.log('STDOUT Wings: ' + data);
                        }).on('close', () => {
                            m.reply(`🎉 **ʏᴇᴀʏʏ! ᴡɪɴɢs sᴜᴅᴀʜ ᴛᴇʀɪɴsᴛᴀʟʟ!**  
💾 Sedang memproses **pengambilan data Panel** untuk melengkapi konfigurasi server-mu.  

🛠️ **Apa yang perlu dilakukan selanjutnya?**  
✨ Tunggu sebentar, proses akan selesai dalam waktu singkat.  
✨ Data seperti username, password, domain, dan lainnya akan segera tersedia.  

🚀 Setelah proses selesai, VPS-mu akan siap digunakan untuk kebutuhanmu!  
`);
                            
                            // Instal Wings kedua
                            instalWings();
                        });
                    });
                });
            });
        }).connect(connSettings);

        async function instalWings() {
            conn.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', (err, stream) => {
                if (err) throw err;
                stream.on('close', async (code, signal) => {
                    let teks = `
🎉 ʙᴇʀɪᴋᴜᴛ ᴅᴇᴛᴀɪʟ ᴀᴋᴜɴ ᴘᴀɴᴇʟ ᴅᴀɴ ᴠᴘꜱ 🎉

🔐 ᴘᴀɴᴇʟ ᴀᴋᴜɴ
• ᴜꜱᴇʀᴘᴀɴᴇʟ: admin
• ᴘᴡᴘᴀɴᴇʟ: ByRulz1243
• ᴅᴏᴍᴀɪɴ: ${domain}

🌐 ᴅᴇᴛᴀɪʟ ᴠᴘꜱ
• ɪᴅ ᴠᴘꜱ: ${dropletId}
• ɪᴘ ᴠᴘꜱ: ${ipVPS}
• ᴘᴀꜱꜱᴡᴏʀᴅ ᴠᴘꜱ: ${password}
• ʀᴇɢɪᴏɴ: 🇸🇬 ꜱɪɴɢᴀᴘᴏʀᴇ
• ᴜꜱᴇʀ ᴠᴘꜱ: ʀᴏᴏᴛ
• ᴏꜱ: ᴜʙᴜɴᴛᴜ 22.04

💡 ɴᴏᴛᴇ:
ꜱɪʟᴀᴋᴀɴ ᴄᴀᴛᴀᴛ ᴅᴇᴛᴀɪʟ ɪɴɪ ᴅᴇɴɢᴀɴ ʙᴀɪᴋ ᴅᴀɴ ɢᴜɴᴀᴋᴀɴ ꜱᴇꜱᴜᴀɪ ᴋᴇʙᴜᴛᴜʜᴀɴ. ᴊɪᴋᴀ ᴀᴅᴀ ᴋᴇɴᴅᴀʟᴀ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴜᴘᴘᴏʀᴛ!

🔥 ᴋᴇᴘᴜᴛᴜꜱᴀɴ ʙᴇʀᴀᴡᴀʟ ᴅᴀʀɪ ꜱɪɴɪ! 🔥`
                    await Rulzx.sendMessage(m.chat, { text: teks });
                }).on('data', (data) => {
                    console.log(data.toString());
                    if (data.toString().includes("Masukkan nama lokasi: ")) {
                        stream.write('Singapore\n');
                    }
                    if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
                        stream.write('Singapore Location\n');
                    }
                    if (data.toString().includes("Masukkan domain: ")) {
                        stream.write(`${domainNode}\n`);
                    }
                    if (data.toString().includes("Masukkan nama node: ")) {
                        stream.write('Rulzx Node\n');
                    }
                    if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
                        stream.write('32000\n');
                    }
                    if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
                        stream.write('32000\n');
                    }
                    if (data.toString().includes("Masukkan Locid: ")) {
                        stream.write('1\n');
                    }
                }).stderr.on('data', (data) => {
                    console.log('Stderr: ' + data);
                });
            });
        }
    } catch (error) {
        console.error(error);
        await m.reply(`Terjadi kesalahan: ${error.message}`);
    }
}
break
case 'delvpsl': {
    if (!isCreator && !isPremium) return reply('❌ Kamu tidak punya akses untuk menggunakan perintah ini!');
    
    const linodeToken = '8dc44d7b87295745275e5577083bc2d4f38bf84e23f117bb892148c7fff7bd20'; // Ganti dengan token API Linode Anda
    const linodeId = args[0]; // ID Linode yang akan dihapus, masukkan sebagai argumen

    if (!linodeId) return reply('⚠️ Harap masukkan ID Linode yang ingin dihapus!');

    reply('⏳ Menghapus VPS Linode...');

    const axios = require('axios');

    axios.delete(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        headers: {
            'Authorization': `Bearer ${linodeToken}`,
        },
    }).then((response) => {
        reply(`✅ VPS dengan ID ${linodeId} berhasil dihapus!`);
    }).catch((error) => {
        if (error.response) {
            reply(`❌ Gagal menghapus VPS!\nStatus: ${error.response.status}\nPesan: ${error.response.data.errors[0].reason}`);
        } else {
            reply(`❌ Terjadi kesalahan saat menghapus VPS: ${error.message}`);
        }
    });
}
    break
case 'listvpsl': {
    if (!isCreator) return reply('❌ Kamu tidak punya akses untuk menggunakan perintah ini!');
    
    const linodeToken = '8dc44d7b87295745275e5577083bc2d4f38bf84e23f117bb892148c7fff7bd20'; // Ganti dengan token API Linode Anda

    reply('⏳ Memuat daftar VPS Linode...');

    const axios = require('axios');

    axios.get('https://api.linode.com/v4/linode/instances', {
        headers: {
            'Authorization': `Bearer ${linodeToken}`,
        },
    }).then((response) => {
        const linodes = response.data.data;

        if (linodes.length === 0) {
            return reply('❌ Tidak ada VPS yang ditemukan!');
        }

        let message = '🖥️ Daftar VPS Linode:\n\n';

        linodes.forEach(linode => {
            message += `🔹 **ID Linode**: ${linode.id}\n`;
            message += `🔹 **Nama Label**: ${linode.label || 'Tidak ada label tersedia'}\n`;
            message += `🔹 **IP**: ${linode.ipv4 ? linode.ipv4.join(', ') : 'Tidak ada IP tersedia'}\n`;
            message += `🔹 **Tipe**: ${linode.plan ? linode.plan.label : 'Tidak tersedia'}\n`;
            message += `🔹 **Status**: ${linode.status || 'Tidak diketahui'}\n`;
            message += `🔹 **Tanggal Pembuatan**: ${linode.created ? new Date(linode.created).toLocaleString() : 'Tidak diketahui'}\n`;
            message += `🔹 **Datacenter**: ${linode.datacenter ? `${linode.datacenter.id} - ${linode.datacenter.name}` : 'Tidak tersedia'}\n`;
            message += `🔹 **Region**: ${linode.region || 'Tidak ada region tersedia'}\n\n`;
        });

        reply(message);
    }).catch((error) => {
        if (error.response) {
            reply(`❌ Gagal memuat daftar VPS!\nStatus: ${error.response.status}\nPesan: ${error.response.data.errors[0].reason}`);
        } else {
            reply(`❌ Terjadi kesalahan: ${error.message}`);
        }
    });
}
        break
case "1gb":
case "2gb":
case "3gb":
case "4gb":
case "5gb":
case "6gb":
case "7gb":
case "8gb":
case "9gb":
case "10gb":
case "unlimited":
case "unli": {
    if (!isCreator) return m.reply("Tidak boleh bg");

    global.panel = text;

    let ram, disknya, cpu;

    switch (command) {
        case "1gb":
            ram = "1000";
            disknya = "1000";
            cpu = "40";
            break;
        case "2gb":
            ram = "2000";
            disknya = "1000";
            cpu = "60";
            break;
        case "3gb":
            ram = "3000";
            disknya = "2000";
            cpu = "80";
            break;
        case "4gb":
            ram = "4000";
            disknya = "2000";
            cpu = "100";
            break;
        case "5gb":
            ram = "5000";
            disknya = "3000";
            cpu = "120";
            break;
        case "6gb":
            ram = "6000";
            disknya = "3000";
            cpu = "140";
            break;
        case "7gb":
            ram = "7000";
            disknya = "4000";
            cpu = "160";
            break;
        case "8gb":
            ram = "8000";
            disknya = "4000";
            cpu = "180";
            break;
        case "9gb":
            ram = "9000";
            disknya = "5000";
            cpu = "200";
            break;
        case "10gb":
            ram = "10000";
            disknya = "5000";
            cpu = "220";
            break;
        case "unlimited":
        case "unli":
            ram = "0"; // Assuming unlimited means 0 for free RAM
            disknya = "0"; // Assuming unlimited means 0 for free Disk
            cpu = "0"; // Assuming unlimited means 0 for free CPU
            break;
        default:
            return m.reply("Pilihan tidak valid.");
    }

    let username = global.panel.toLowerCase();
    let email = `${username}@gmail.com`;
    let name = `${username} Server`;
    let password = `${username}${crypto.randomBytes(2).toString('hex')}`;

    // Kirim pesan untuk meminta username
    await Rulzx.sendMessage(m.chat, {
        text: "Masukkan username yang ingin kamu gunakan untuk panel."
    });

    // Fungsi untuk memeriksa pesan
    const checkForResponse = async () => {
        const allMessages = await Rulzx.fetchMessages(m.chat); // Assuming this function fetches messages
        return allMessages.find((message) => message.from === m.chat && message.text);
    };

    // Set timeout untuk menghentikan polling setelah 30 detik
    let timeoutReached = false;
    let response = null;

    // Cek polling setiap 3 detik
    const timeout = setTimeout(() => {
        timeoutReached = true;
    }, 30000); // 30 detik

    while (!timeoutReached && !response) {
        response = await checkForResponse(); // Cek apakah ada pesan baru
        if (response) {
            global.panel = response.text.trim(); // Set username
            console.log("Username diterima: ", global.panel);
            clearTimeout(timeout); // Hentikan timeout jika respons ditemukan
            break; // Berhenti jika sudah mendapatkan respons
        }
        await new Promise((resolve) => setTimeout(resolve, 3000)); // Tunggu 3 detik sebelum mencoba lagi
    }

    if (!response) {
        return m.reply("Timeout! Username tidak diterima.");
    }

    // Lanjutkan dengan kode untuk membuat server menggunakan username yang diberikan
    try {
        let userResponse = await fetch(`${global.domain}/api/application/users`, {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": `Bearer ${global.apikey}`
            },
            body: JSON.stringify({
                email,
                username: global.panel,
                first_name: name,
                last_name: "Server",
                language: "en",
                password: password
            })
        });

        let userData = await userResponse.json();
        if (userData.errors) return m.reply(JSON.stringify(userData.errors[0], null, 2));

        let usr_id = userData.attributes.id;
        if (!usr_id) return m.reply("Gagal mendapatkan ID user dari API!");

        let eggResponse = await fetch(`${global.domain}/api/application/nests/5/eggs/15`, {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": `Bearer ${global.apikey}`
            }
        });

        let eggData = await eggResponse.json();
        if (eggData.errors) return m.reply(JSON.stringify(eggData.errors[0], null, 2));

        let startup_cmd = eggData.attributes.startup;

        let serverResponse = await fetch(`${global.domain}/api/application/servers`, {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": `Bearer ${global.apikey}`
            },
            body: JSON.stringify({
                name,
                description: name,
                user: usr_id,
                egg: 15,
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
                startup: startup_cmd,
                environment: {
                    INST: "npm",
                    USER_UPLOAD: "0",
                    AUTO_UPDATE: "0",
                    CMD_RUN: "npm start"
                },
                limits: {
                    memory: ram,
                    swap: 0,
                    disk: disknya,
                    io: 500,
                    cpu
                },
                feature_limits: {
                    databases: 5,
                    backups: 5,
                    allocations: 5
                },
                deploy: {
                    locations: [1],
                    dedicated_ip: false,
                    port_range: []
                }
            })
        });

        let serverData = await serverResponse.json();
        if (serverData.errors) return m.reply(JSON.stringify(serverData.errors[0], null, 2));

        let server = serverData.attributes;

        let recipient = m.isGroup ? m.sender : m.chat;
        let message = `Berhasil Membuat Akun Panel ✅

* ID Server: ${server.id}
* Nama: ${name}
* Username: ${global.panel}
* Password: ${password}
* Login: ${global.domain}
* RAM: ${ram === "0" ? "Unlimited" : ram.slice(0, -3) + "GB"}
* CPU: ${cpu === "0" ? "Unlimited" : cpu + "%"}
* Disk: ${disknya === "0" ? "Unlimited" : disknya.slice(0, -3) + "GB"}
* Expired Server: 1 Bulan

Rules Pembelian Panel ⚠
- Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
- Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
- Garansi Aktif 10 Hari (1x replace)
- Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian`;

        await Rulzx.sendMessage(recipient, { text: message }, { quoted: m });
        delete global.panel;
    } catch (error) {
        console.error("Error:", error);
        m.reply("Terjadi kesalahan saat membuat panel.");
    }
}
break
case "itd2": {
    if (!isCreator) return reply("Perintah ini hanya dapat dijalankan oleh pemilik bot!");

    if (!text || !text.split("|")) return reply("Format salah!\nPenggunaan: itd ipvps|passwordvps");
    let vii = text.split("|");
    if (vii.length < 2) return reply("Format salah!\nPenggunaan: installtemastellar ipvps|passwordvps");

    const ipvps = vii[0].trim(); // IP VPS
    const passwd = vii[1].trim(); // Password VPS

    // Konfigurasi koneksi SSH
    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd,
    };

    const conn = new Client();
    const command = `bash <(curl -s https://raw.githubusercontent.com/khoirulhuda-cyber/darktemeptero-BYIkhrulz/refs/heads/main/darkptero.sh)`;

    conn.on('ready', () => {
        reply("Memulai proses instalasi tema darkenate untuk Pterodactyl...\nTunggu hingga 1-10 menit.");
        conn.exec(command, (err, stream) => {
            if (err) {
                conn.end();
                return reply("Gagal menjalankan perintah instalasi. Periksa kembali koneksi VPS Anda.");
            }

            stream.on('close', (code, signal) => {
                conn.end();
                reply("✅ Instalasi tema darkenate dan blueprint berhasil diselesaikan!");
            }).on('data', (data) => {
                console.log("STDOUT:", data.toString());
                // Input otomatis ke script
stream.write("rulz\n"); // Key Token: skyzodev
stream.write("1\n");
stream.write("2\n");
stream.write("y\n");
stream.write("y\n");
stream.write("x\n");     // Konfirmasi 'yes'

            }).stderr.on('data', (data) => {
                console.error("STDERR:", data.toString());
            });
        });
    });

    conn.on('error', (err) => {
        console.error("Connection Error:", err);
        reply("⚠️ Gagal terhubung ke VPS. Pastikan IP dan password yang dimasukkan benar.");
    });

    conn.connect(connSettings);
}
break
case "itd3": {
    if (!isCreator) return reply("Perintah ini hanya dapat dijalankan oleh pemilik bot!");

    if (!text || !text.split("|")) return reply("Format salah!\nPenggunaan: itd ipvps|passwordvps");
    let vii = text.split("|");
    if (vii.length < 2) return reply("Format salah!\nPenggunaan: installtemastellar ipvps|passwordvps");

    const ipvps = vii[0].trim(); // IP VPS
    const passwd = vii[1].trim(); // Password VPS

    // Konfigurasi koneksi SSH
    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd,
    };

    const conn = new Client();
    const command = `bash <(curl -s https://raw.githubusercontent.com/khoirulhuda-cyber/darktemeptero-BYIkhrulz/refs/heads/main/darkptero.sh)`;

    conn.on('ready', () => {
        reply("Memulai proses instalasi tema darkenate untuk Pterodactyl...\nTunggu hingga 1-10 menit.");
        conn.exec(command, (err, stream) => {
            if (err) {
                conn.end();
                return reply("Gagal menjalankan perintah instalasi. Periksa kembali koneksi VPS Anda.");
            }

            stream.on('close', (code, signal) => {
                conn.end();
                reply("✅ Instalasi tema darkenate dan blueprint berhasil diselesaikan!");
            }).on('data', (data) => {
                console.log("STDOUT:", data.toString());
                // Input otomatis ke script
stream.write("rulz\n"); // Key Token: skyzodev
stream.write("1\n");     // Konfirmasi 'yes'
stream.write("1\n");
stream.write("x\n");// Input pilihan terakhir

            }).stderr.on('data', (data) => {
                console.error("STDERR:", data.toString());
            });
        });
    });

    conn.on('error', (err) => {
        console.error("Connection Error:", err);
        reply("⚠️ Gagal terhubung ke VPS. Pastikan IP dan password yang dimasukkan benar.");
    });

    conn.connect(connSettings);
}
break
case 'domain1': {
    if (!isCreator) return m.reply("Maaf Tod, fitur ini hanya dapat digunakan di grup tertentu!");

    function subDomain1(host, ip) {
        return new Promise((resolve) => {
            const zone = "5168a01d8ab92ebfeb09b0b424fc4c6a";
            const apitoken = "UwRZHlbQrakwO6u211wTKc2u-Rv2MguMr7f1-VBb";
            const tld = "alertdata.me";

            axios.post(
                `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                {
                    type: "A",
                    name: `${host}.${tld}`,
                    content: ip,
                    ttl: 3600,
                    proxied: false,
                },
                {
                    headers: {
                        Authorization: `Bearer ${apitoken}`,
                        "Content-Type": "application/json",
                    },
                }
            )
                .then((e) => {
                    const res = e.data;
                    if (res.success) {
                        resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                    }
                })
                .catch((e) => {
                    const err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                    resolve({ success: false, error: String(err1) });
                });
        });
    }

    const raw1 = args.join(" ").trim();
    if (!raw1) return m.reply(`Penggunaan: ${prefix + command} Host|Ip`);

    const host1 = raw1.split("|")[0].trim().replace(/[^a-z0-9.-]/gi, "");
    if (!host1) return m.reply("Host tidak valid! Pastikan hanya menggunakan huruf, angka, tanda '-' (strip), dan '.' (titik).");

    const ip1 = raw1.split("|")[1]?.trim().replace(/[^0-9.]/gi, "");
    if (!ip1 || ip1.split(".").length !== 4) return m.reply(ip1 ? "IP tidak valid!" : "IP tidak ditemukan!");

    subDomain1(host1, ip1).then((e) => {
        if (e.success) {
            m.reply(`┏━━━━━━━━━━━━━━━━━━━
┃ IP: ${e.ip}
┣━━━━━━━━━━━━━━━━━━━
┃ Username: ${e.name}
┣━━━━━━━━━━━━━━━━━━━
┃ Created By: rulzz
┗━━━━━━━━━━━━━━━━━━━`);
        } else {
            m.reply(`Gagal membuat subdomain.\nPesan: ${e.error}`);
        }
    });
}
break

case 'domain2': {
    if (!isCreator) return m.reply("Maaf Tod, fitur ini hanya dapat digunakan di grup tertentu!");

    function subDomain1(host, ip) {
        return new Promise((resolve) => {
            const zone = "859a622eb62a96fd3b2340a52d538bc6";
            const apitoken = "UwRZHlbQrakwO6u211wTKc2u-Rv2MguMr7f1-VBb";
            const tld = "webservers.software";

            axios.post(
                `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                {
                    type: "A",
                    name: `${host}.${tld}`,
                    content: ip,
                    ttl: 3600,
                    proxied: false,
                },
                {
                    headers: {
                        Authorization: `Bearer ${apitoken}`,
                        "Content-Type": "application/json",
                    },
                }
            )
                .then((e) => {
                    const res = e.data;
                    if (res.success) {
                        resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                    }
                })
                .catch((e) => {
                    const err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                    resolve({ success: false, error: String(err1) });
                });
        });
    }

    const raw1 = args.join(" ").trim();
    if (!raw1) return m.reply(`Penggunaan: ${prefix + command} Host|Ip`);

    const host1 = raw1.split("|")[0].trim().replace(/[^a-z0-9.-]/gi, "");
    if (!host1) return m.reply("Host tidak valid! Pastikan hanya menggunakan huruf, angka, tanda '-' (strip), dan '.' (titik).");

    const ip1 = raw1.split("|")[1]?.trim().replace(/[^0-9.]/gi, "");
    if (!ip1 || ip1.split(".").length !== 4) return m.reply(ip1 ? "IP tidak valid!" : "IP tidak ditemukan!");

    subDomain1(host1, ip1).then((e) => {
        if (e.success) {
            m.reply(`┏━━━━━━━━━━━━━━━━━━━
┃ IP: ${e.ip}
┣━━━━━━━━━━━━━━━━━━━
┃ Username: ${e.name}
┣━━━━━━━━━━━━━━━━━━━
┃ Created By: rulzz
┗━━━━━━━━━━━━━━━━━━━`);
        } else {
            m.reply(`Gagal membuat subdomain.\nPesan: ${e.error}`);
        }
    });
}
break
case 'domain3': {
    if (!isCreator) return m.reply("Maaf Tod, fitur ini hanya dapat digunakan di grup tertentu!");

    function subDomain1(host, ip) {
        return new Promise((resolve) => {
            const zone = "09b85878919f7a9d75c765fc6ba436fc";
            const apitoken = "8r-j-ROIKnQLhhkdrwwtv2d2tT2sSlWsqUQIhsKr";
            const tld = "rulzcloud.systems";

            axios.post(
                `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                {
                    type: "A",
                    name: `${host}.${tld}`,
                    content: ip,
                    ttl: 3600,
                    proxied: false,
                },
                {
                    headers: {
                        Authorization: `Bearer ${apitoken}`,
                        "Content-Type": "application/json",
                    },
                }
            )
                .then((e) => {
                    const res = e.data;
                    if (res.success) {
                        resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                    }
                })
                .catch((e) => {
                    const err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                    resolve({ success: false, error: String(err1) });
                });
        });
    }

    const raw1 = args.join(" ").trim();
    if (!raw1) return m.reply(`Penggunaan: ${prefix + command} Host|Ip`);

    const host1 = raw1.split("|")[0].trim().replace(/[^a-z0-9.-]/gi, "");
    if (!host1) return m.reply("Host tidak valid! Pastikan hanya menggunakan huruf, angka, tanda '-' (strip), dan '.' (titik).");

    const ip1 = raw1.split("|")[1]?.trim().replace(/[^0-9.]/gi, "");
    if (!ip1 || ip1.split(".").length !== 4) return m.reply(ip1 ? "IP tidak valid!" : "IP tidak ditemukan!");

    subDomain1(host1, ip1).then((e) => {
        if (e.success) {
            m.reply(`┏━━━━━━━━━━━━━━━━━━━
┃ IP: ${e.ip}
┣━━━━━━━━━━━━━━━━━━━
┃ Username: ${e.name}
┣━━━━━━━━━━━━━━━━━━━
┃ Created By: rulzz
┗━━━━━━━━━━━━━━━━━━━`);
        } else {
            m.reply(`Gagal membuat subdomain.\nPesan: ${e.error}`);
        }
    });
}
break



case 'connectvps': {
    const args = text.split(',');
    if (args.length < 3) return reply(`*Format salah!*\nPenggunaan: ${prefix}runvps username,ip,password`);

    const [username, ip, password] = args;

    // Cek jika ada koneksi aktif
    if (session.activeConnection) {
        return reply('`Sudah ada koneksi aktif. Ketik .disvps untuk memutuskan koneksi saat ini.`');
    }

    const connSettings = {
        host: ip,
        port: 22,
        username,
        password,
    };

    const conn = new Client();

    conn.on('ready', () => {
        session.activeConnection = conn;  // Simpan koneksi aktif
        session.user = username;         // Simpan username
        session.ip = ip;                 // Simpan IP
        session.startTime = new Date();  // Simpan waktu mulai
        reply(`\`Berhasil terhubung ke VPS ${username}@${ip}. Ketik .ssh <command> untuk menjalankan perintah.\``);
    });

    conn.on('error', (err) => {
        console.error('Error koneksi:', err);
        reply('`Gagal terhubung ke VPS. Periksa kembali IP, username, atau password.`');
    });

    conn.on('end', () => {
        reply('`Koneksi ke VPS telah terputus.`');
        session.activeConnection = null; // Reset koneksi
        session.user = null;
        session.ip = null;
        session.startTime = null;
    });

    conn.connect(connSettings);
}
break

// Case ssh untuk menjalankan perintah di VPS
case 'ssh': {
    const command = text.trim();
    if (!command) return reply('`Perintah tidak boleh kosong. Gunakan .ssh <command>`');

    // Cek apakah ada koneksi aktif
    if (!session.activeConnection) {
        return reply('`Tidak ada koneksi aktif. Gunakan .runvps untuk terhubung ke VPS.`');
    }

    session.activeConnection.exec(command, (err, stream) => {
        if (err) {
            console.error('Error menjalankan perintah:', err);
            return reply('`Terjadi kesalahan saat menjalankan perintah.`');
        }

        let output = '';
        let errorOutput = '';

        stream
            .on('close', (code, signal) => {
                reply(
                    `*Perintah selesai dijalankan!*\n\n*Output:*\n${output || 'Tidak ada output.'}\n\n*Error:*\n${errorOutput || 'Tidak ada error.'}`
                );
            })
            .on('data', (data) => {
                output += data.toString();
            })
            .stderr.on('data', (data) => {
                errorOutput += data.toString();
            });
    });
}
break

// Case disvps untuk memutuskan koneksi
case 'disconnectvps': {
    // Cek apakah ada koneksi aktif
    if (!session.activeConnection) {
        return reply('`Tidak ada koneksi aktif untuk diputus.`');
    }

    session.activeConnection.end(); // Putuskan koneksi
    reply(`\`Koneksi ke VPS ${session.user}@${session.ip} telah diputus.\``);

    // Reset data sesi
    session.activeConnection = null;
    session.user = null;
    session.ip = null;
    session.startTime = null;
}
break

// Case statusvps untuk melihat status koneksi aktif
case 'statusvps': {
    if (!session.activeConnection) {
        return reply('`Tidak ada koneksi aktif saat ini.`');
    }

    const duration = Math.floor((new Date() - session.startTime) / 1000); // Durasi dalam detik
    reply(
        `*Status Koneksi VPS:*\n\n- *User:* ${session.user}\n- *IP:* ${session.ip}\n- *Durasi:* ${duration} detik`
    );
}
break
    case 'iw' : case 'instalwings' : {
    if (!isCreator) return onlyOwn();
    let t = text.split(',');
    if (t.length < 3) return reply(`*Format salah!*\nPenggunaan: ${prefix}ipanel3 ipvps,password,domain,node`);
    
    let ipvps = t[0];
    let passwd = t[1];
    let subdomain = t[2];
    let domainnode = t[3];
    let ramvps = 32000; // RAM otomatis 32GB

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd,
    };
    
    let password = "ByRulz1243"; // Password tetap
    const commandWings = 'bash <(curl -s https://pterodactyl-installer.se)';
    const conn = new Client();
 conn.on('ready', () => {
        reply('INSTAL WINGS SEDANG DIMULAI');
                conn.exec(commandWings, (err, stream) => {
                    if (err) throw err;

                    stream.on('data', (data) => {
                        if (data.toString().includes('Input')) {
                            stream.write('1\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write(`${subdomain}\n`);
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('user\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('1248\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write(`${domainnode}\n`);
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('admin@gmail.com\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        console.log('STDOUT Wings: ' + data);
                    }).on('close', () => {
                        reply('`WINGS PERTAMA SUKSES TERINSTALL, LANJUT PROSES SELANJUTNYA`');
                        
                        // Instal Wings kedua
                        instalWings();
                    });
                });
    }).connect(connSettings);

    async function instalWings() {
        conn.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', (err, stream) => {
            if (err) throw err;
            stream.on('close', async (code, signal) => {
                let teks = `
Berikut Detail Akun Panel :

* Username : admin
* Password : ${password}
* Domain : ${subdomain}

Note : Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

Cara Menjalankan Wings :
ketik .startwings ipvps|pwvps|tokenwings
`
                await Rulzx.sendMessage(m.chat, { text: teks });
}).on('data', (data) => {
                console.log(data.toString());
                if (data.toString().includes("Masukkan nama lokasi: ")) {
                    stream.write('Singapore\n');
                }
                if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
                    stream.write('Singapore Location\n');
                }
                if (data.toString().includes("Masukkan domain: ")) {
                    stream.write(`${domainnode}\n`);
                }
                if (data.toString().includes("Masukkan nama node: ")) {
                    stream.write('Rulzx Node\n');
                }
                if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
                    stream.write(`${ramvps}\n`);
                }
                if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
                    stream.write(`${ramvps}\n`);
                }
                if (data.toString().includes("Masukkan Locid: ")) {
                    stream.write('1\n');
                }
            }).stderr.on('data', (data) => {
                console.log('Stderr: ' + data);
            });
        });
    }
}
break
case 'ipanel3': {
    if (!isCreator) return onlyOwn();
    let t = text.split(',');
    if (t.length < 3) return reply(`*Format salah!*\nPenggunaan: ${prefix}ipanel3 ipvps,password,domain,node`);
    
    let ipvps = t[0];
    let passwd = t[1];
    let subdomain = t[2];
    let domainnode = t[3];
    let ramvps = 32000; // RAM otomatis 32GB

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd,
    };
    
    let password = "ByRulz1243"; // Password tetap
    const commandPanel = 'bash <(curl -s https://pterodactyl-installer.se)';
    const commandWings = 'bash <(curl -s https://pterodactyl-installer.se)';
    const conn = new Client();
 conn.on('ready', () => {
        reply('`PROSES PENGINSTALLAN PANEL TUNGGU YA`');
        conn.exec(commandPanel, (err, stream) => {
            if (err) throw err;

            stream.on('data', (data) => {
                if (data.toString().includes('Input')) {
                    stream.write('0\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('1248\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('Asia/Jakarta\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('admin@gmail.com\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('admin@gmail.com\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('admin\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('adm\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('adm\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write(`${password}\n`);
                }
                if (data.toString().includes('Input')) {
                    stream.write(`${subdomain}\n`);
                }
                if (data.toString().includes('Input')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('yes\n');
                }
                if (data.toString().includes('Please read the Terms of Service')) {
                    stream.write('A\n');
                }
                if (data.toString().includes('Please read the Terms of Service')) {
                    stream.write('Y\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('1\n');
                }
                console.log('STDOUT Panel: ' + data);
            }).on('close', () => {
                reply('`PANEL SUKSES TERINSTALL, LANJUT INSTALL WINGS`');

                // Instal Wings pertama
                conn.exec(commandWings, (err, stream) => {
                    if (err) throw err;

                    stream.on('data', (data) => {
                        if (data.toString().includes('Input')) {
                            stream.write('1\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write(`${subdomain}\n`);
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('user\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('1248\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write(`${domainnode}\n`);
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('admin@gmail.com\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        console.log('STDOUT Wings: ' + data);
                    }).on('close', () => {
                        reply('`WINGS PERTAMA SUKSES TERINSTALL, LANJUT PROSES SELANJUTNYA`');
                        
                        // Instal Wings kedua
                        instalWings();
                    });
                });
            });
        });
    }).connect(connSettings);

    async function instalWings() {
        conn.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', (err, stream) => {
            if (err) throw err;
            stream.on('close', async (code, signal) => {
                let teks = `
Berikut Detail Akun Panel :

* Username : admin
* Password : ${password}
* Domain : ${subdomain}

Note : Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

Cara Menjalankan Wings :
ketik .startwings ipvps|pwvps|tokenwings
`
                await Rulzx.sendMessage(m.chat, { text: teks });
}).on('data', (data) => {
                console.log(data.toString());
                if (data.toString().includes("Masukkan nama lokasi: ")) {
                    stream.write('Singapore\n');
                }
                if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
                    stream.write('Singapore Location\n');
                }
                if (data.toString().includes("Masukkan domain: ")) {
                    stream.write(`${domainnode}\n`);
                }
                if (data.toString().includes("Masukkan nama node: ")) {
                    stream.write('Rulzx Node\n');
                }
                if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
                    stream.write(`${ramvps}\n`);
                }
                if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
                    stream.write(`${ramvps}\n`);
                }
                if (data.toString().includes("Masukkan Locid: ")) {
                    stream.write('1\n');
                }
            }).stderr.on('data', (data) => {
                console.log('Stderr: ' + data);
            });
        });
    }
}
break
case 'ipanel': {
    if (!isCreator) return onlyOwn();
    let t = text.split(',');
    if (t.length < 5) return reply(`*Format salah!*\nPenggunaan: ${prefix}installpanel1 ipvps,password,domainpnl,domainnode,ramvps (Contoh 80000 8gb)`);
    let ipvps = t[0];
    let passwd = t[1];
    let subdomain = t[2];
    let domainnode = t[3];
    let ramvps = t[4];
    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };
    let password = "ByRulz1243"; // Password statis
    const commandPanel = 'bash <(curl -s https://pterodactyl-installer.se)';
    const commandWings = 'bash <(curl -s https://pterodactyl-installer.se)';
    const conn = new Client();

    conn.on('ready', () => {
        reply('`PROSES PENGINSTALLAN PANEL TUNGGU YA GA SABARAN TAK KOKOP`');
        conn.exec(commandPanel, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Panel installation stream closed with code ' + code + ' and signal ' + signal);
                installWings(conn, domainnode, subdomain, password, ramvps);
            }).on('data', (data) => {
                handlePanelInstallationInput(data, stream, subdomain, password);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).connect(connSettings);

    async function installWings(conn, domainnode, subdomain, password, ramvps) {
        reply('`PROSES PENGINSTALLAN WINGS TUNGGU YA MANIEZ`');
        conn.exec(commandWings, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Wings installation stream closed with code ' + code + ' and signal ' + signal);
                createNode(conn, domainnode, ramvps, subdomain, password);
            }).on('data', (data) => {
                handleWingsInstallationInput(data, stream, domainnode, subdomain);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }

    async function createNode(conn, domainnode, ramvps, subdomain, password) {
        const command = `${global.bash}`;
        reply('`MEMULAI CREATE NODE & LOCATION`');

        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Node creation stream closed with code ' + code + ' and signal ' + signal);
                conn.end();
                sendPanelData(subdomain, password);
            }).on('data', (data) => {
                handleNodeCreationInput(data, stream, domainnode, ramvps);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }

    function sendPanelData(subdomain, password) {
        reply(`*DATA PANEL ANDA*\n\n*USERNAME:* admin\n*PASSWORD:* ${password}\n*LOGIN:* ${subdomain}\n\nNote: Semua Instalasi Telah Selesai Silahkan Create Allocation Di Node Yang Di buat Oleh Bot Dan Ambil Token Configuration dan ketik .startwings (token) \nNote: *HARAP TUNGGU 1-5MENIT BIAR WEB BISA DI BUKA*`);
    }

    function handlePanelInstallationInput(data, stream, subdomain, password) {
        if (data.toString().includes('Input')) {
            stream.write('0\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('1248\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('Asia/Jakarta\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('admin@gmail.com\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('admin@gmail.com\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('admin\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('adm\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('adm\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write(`${subdomain}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('yes\n');
        }
        if (data.toString().includes('Please read the Terms of Service')) {
            stream.write('Y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('1\n');
        }
        console.log('STDOUT: ' + data);
    }

    function handleWingsInstallationInput(data, stream, domainnode, subdomain) {
        if (data.toString().includes('Input')) {
            stream.write('1\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`${subdomain}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('user\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('1248\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`${domainnode}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('admin@gmail.com\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        console.log('STDOUT: ' + data);
    }

    function handleNodeCreationInput(data, stream, domainnode, ramvps) {
        stream.write(`${global.tokeninstall}\n`);
        stream.write('4\n');
        stream.write('SGP\n');
        stream.write('Done Abangkuhh\n');
        stream.write(`${domainnode}\n`);
        stream.write('NODES\n');
        stream.write(`${ramvps}\n`);
        stream.write(`${ramvps}\n`);
        stream.write('1\n');
        console.log('STDOUT: ' + data);
    }
}
break
case "startwings": case "sw": {
    if (!isCreator) return Reply(mess.owner);
    let t = text.split(',');
    if (t.length < 3) return m.reply("ipvps,pwvps,token_node");

    let ipvps = t[0];
    let passwd = t[1];
    let token = t[2];

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `${token} && systemctl start wings`;
    const ress = new Client();

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) throw err;

            stream.on('close', async (code, signal) => {
                await m.reply("Berhasil menjalankan wings ✅\n* Status wings : aktif");
                ress.end();
            }).on('data', async (data) => {
                await console.log(data.toString());
            }).stderr.on('data', (data) => {
                stream.write("y\n");
                stream.write("systemctl start wings\n");
                m.reply('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        m.reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break
case 'ipanel2': {
    if (!isCreator) return onlyOwn();
    let t = text.split(',');
    if (t.length < 3) return reply(`*Format salah!*\nPenggunaan: ${prefix}ipanel2 ipvps,password,namadomain`);
    
    let ipvps = t[0];
    let passwd = t[1];
    let domain = t[2];
    let ramvps = 32000; // RAM otomatis 32GB
    let subdomain = `${domain}.rulzcloud.systems`;
    let domainnode = `${domain}-node.rulzcloud.systems`;

    // Cloudflare Zone dan API Token
    const zone = "09b85878919f7a9d75c765fc6ba436fc"; // Ganti dengan Zone ID Cloudflare Anda
    const apitoken = "8r-j-ROIKnQLhhkdrwwtv2d2tT2sSlWsqUQIhsKr"; // Ganti dengan API Token Cloudflare Anda
    const tld = "rulzcloud.systems"; // Top Level Domain

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd,
    };
    
    let password = "ByRulz1243"; // Password tetap
    const commandPanel = 'bash <(curl -s https://pterodactyl-installer.se)';
    const commandWings = 'bash <(curl -s https://pterodactyl-installer.se)';
    const conn = new Client();

    async function createDNSRecord(name) {
        try {
            const response = await axios.post(
                `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                {
                    type: "A",
                    name: name,
                    content: ipvps,
                    ttl: 120,
                    proxied: false, // DNS-Only (tanpa Proxy)
                },
                {
                    headers: {
                        "Authorization": `Bearer ${apitoken}`,
                        "Content-Type": "application/json",
                    },
                }
            );
            if (response.data.success) {
                console.log(`DNS Record berhasil dibuat: ${name}`);
                reply(`DNS Record untuk ${name} berhasil dibuat.`);
            } else {
                console.log(`Gagal membuat DNS Record: ${name}`, response.data.errors);
                reply(`Gagal membuat DNS Record untuk ${name}.`);
            }
        } catch (error) {
            console.error(`Error membuat DNS Record: ${error.message}`);
            reply(`Terjadi kesalahan saat membuat DNS Record untuk ${name}.`);
        }
    }

    conn.on('ready', async () => {
        reply('`Proses pengaturan DNS...`');
        await createDNSRecord(subdomain);  // Buat DNS Record untuk Panel
        await createDNSRecord(domainnode); // Buat DNS Record untuk Wings

        reply('`PROSES PENGINSTALLAN PANEL TUNGGU YA`');
        conn.exec(commandPanel, (err, stream) => {
            if (err) throw err;

            stream.on('data', (data) => {
                if (data.toString().includes('Input')) {
                    stream.write('0\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('1248\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('Asia/Jakarta\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('admin@gmail.com\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('admin@gmail.com\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('admin\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('adm\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('adm\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write(`${password}\n`);
                }
                if (data.toString().includes('Input')) {
                    stream.write(`${subdomain}\n`);
                }
                if (data.toString().includes('Input')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('yes\n');
                }
                if (data.toString().includes('Please read the Terms of Service')) {
                    stream.write('A\n');
                }
                if (data.toString().includes('Please read the Terms of Service')) {
                    stream.write('Y\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('\n');
                }
                if (data.toString().includes('Input')) {
                    stream.write('1\n');
                }
                console.log('STDOUT Panel: ' + data);
            }).on('close', () => {
                reply('`PANEL SUKSES TERINSTALL, LANJUT INSTALL WINGS`');

                // Instal Wings pertama
                conn.exec(commandWings, (err, stream) => {
                    if (err) throw err;

                    stream.on('data', (data) => {
                        if (data.toString().includes('Input')) {
                            stream.write('1\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write(`${subdomain}\n`);
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('user\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('1248\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write(`${domainnode}\n`);
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('admin@gmail.com\n');
                        }
                        if (data.toString().includes('Input')) {
                            stream.write('y\n');
                        }
                        console.log('STDOUT Wings: ' + data);
                    }).on('close', () => {
                        reply('`WINGS PERTAMA SUKSES TERINSTALL, LANJUT PROSES SELANJUTNYA`');
                        
                        // Instal Wings kedua
                        instalWings();
                    });
                });
            });
        });
    }).connect(connSettings);

    async function instalWings() {
        conn.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', (err, stream) => {
            if (err) throw err;
            stream.on('close', async (code, signal) => {
                let teks = `
Berikut Detail Akun Panel :

* Username : admin
* Password : ${password}
* Domain : ${subdomain}

Note : Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

Cara Menjalankan Wings :
ketik .startwings ipvps|pwvps|tokenwings
`
                await Rulzx.sendMessage(m.chat, { text: teks });
}).on('data', (data) => {
                console.log(data.toString());
                if (data.toString().includes("Masukkan nama lokasi: ")) {
                    stream.write('Singapore\n');
                }
                if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
                    stream.write('Singapore Location\n');
                }
                if (data.toString().includes("Masukkan domain: ")) {
                    stream.write(`${domainnode}\n`);
                }
                if (data.toString().includes("Masukkan nama node: ")) {
                    stream.write('Rulzx Node\n');
                }
                if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
                    stream.write(`${ramvps}\n`);
                }
                if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
                    stream.write(`${ramvps}\n`);
                }
                if (data.toString().includes("Masukkan Locid: ")) {
                    stream.write('1\n');
                }
            }).stderr.on('data', (data) => {
                console.log('Stderr: ' + data);
            });
        });
    }
}
break
case 'migrate': {
    if (!isCreator) return m.reply('Hanya creator yang bisa akses fitur ini!');

    let t = text.split(',');
    if (t.length < 2) return m.reply(`*Format salah!*\nPenggunaan: ${prefix}migrate ipvps,password`);

    let ipvps = t[0];
    let passwd = t[1];

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = 'php artisan migrate'; // Perintah yang akan dijalankan
    const changeDirCommand = 'cd /var/www/pterodactyl && ' + command; // Perintah untuk pindah direktori dan menjalankan migrate

    const conn = new Client();
    let isSuccess = false; // Flag untuk menentukan keberhasilan koneksi

    conn.on('ready', () => {
        isSuccess = true; // Set flag menjadi true jika koneksi berhasil
        m.reply('*PROSES MIGRASI DIMULAI, MOHON TUNGGU SEBENTAR*');

        conn.shell((err, stream) => {
            if (err) throw err;

            stream.on('close', (code, signal) => {
                console.log('Stream closed with code ' + code + ' and signal ' + signal);
                m.reply('`SUKSES MELAKUKAN MIGRASI DATABASE`');
                conn.end();
            }).on('data', (data) => {
                // Cek output dari perintah untuk prompt interaktif
                console.log('STDOUT: ' + data.toString());

                // Cek jika prompt konfirmasi muncul
                if (data.toString().includes('Are you sure you want to run this command?')) {
                    // Kirimkan input untuk memilih 'Yes' menggunakan tombol panah kiri
                    stream.write('\x1b[D'); // Tombol panah kiri
                    
                    // Tekan Enter untuk melanjutkan
                    stream.write('\n');
                }
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });

            // Jalankan perintah cd /var/www/pterodactyl dan kemudian perintah migrate
            stream.write(changeDirCommand + '\n');
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        m.reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);

}
break
case "its": {
    if (!isCreator) return reply("Perintah ini hanya dapat dijalankan oleh pemilik bot!");

    if (!text || !text.split(",")) return reply("Format salah!\nPenggunaan: itd ipvps,passwordvps");
    let vii = text.split(",");
    if (vii.length < 2) return reply("Format salah!\nPenggunaan: installtemastellar ipvps,passwordvps");

    const ipvps = vii[0].trim(); // IP VPS
    const passwd = vii[1].trim(); // Password VPS

    // Konfigurasi koneksi SSH
    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd,
    };

    const conn = new Client();
    const command = `bash <(curl https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;

    conn.on('ready', () => {
        reply("Memulai proses instalasi tema stellar untuk Pterodactyl...\nTunggu hingga 1-10 menit.");
        conn.exec(command, (err, stream) => {
            if (err) {
                conn.end();
                return reply("Gagal menjalankan perintah instalasi. Periksa kembali koneksi VPS Anda.");
            }

            stream.on('close', (code, signal) => {
                conn.end();
                reply("✅ Instalasi tema stellar dan blueprint berhasil diselesaikan!");

                // Setelah instalasi selesai, jalankan proses migrasi
                m.reply('*PROSES MIGRASI DIMULAI, MOHON TUNGGU SEBENTAR*');

                // Perintah migrate untuk dijalankan setelah instalasi
                const migrateCommand = 'php artisan migrate';
                const changeDirCommand = 'cd /var/www/pterodactyl && ' + migrateCommand;

                const migrateConn = new Client();

                migrateConn.on('ready', () => {
                    migrateConn.shell((err, stream) => {
                        if (err) throw err;

                        stream.on('close', (code, signal) => {
                            console.log('Stream closed with code ' + code + ' and signal ' + signal);
                            m.reply('`SUKSES MELAKUKAN MIGRASI DATABASE`');
                            migrateConn.end();
                        }).on('data', (data) => {
                            console.log('STDOUT: ' + data.toString());

                            // Cek jika prompt konfirmasi muncul
                            if (data.toString().includes('Are you sure you want to run this command?')) {
                                // Kirimkan input untuk memilih 'Yes' menggunakan tombol panah kiri
                                stream.write('\x1b[D'); // Tombol panah kiri
                                
                                // Tekan Enter untuk melanjutkan
                                stream.write('\n');
                            }
                        }).stderr.on('data', (data) => {
                            console.log('STDERR: ' + data);
                        });

                        // Jalankan perintah cd /var/www/pterodactyl dan kemudian perintah migrate
                        stream.write(changeDirCommand + '\n');
                    });
                }).on('error', (err) => {
                    console.log('Connection Error: ' + err);
                    m.reply('Katasandi atau IP tidak valid');
                }).connect(connSettings);
            }).on('data', (data) => {
                console.log("STDOUT:", data.toString());
                // Input otomatis ke script
                stream.write('skyzodev\n');
                stream.write('1\n');
                stream.write('1\n');
                stream.write('y\n');
                stream.write('x\n');
            }).stderr.on('data', (data) => {
                console.error("STDERR:", data.toString());
            });
        });
    });

    conn.on('error', (err) => {
        console.error("Connection Error:", err);
        reply("⚠️ Gagal terhubung ke VPS. Pastikan IP dan password yang dimasukkan benar.");
    });

    conn.connect(connSettings);
}
break
case "menuxc": {
  // Hapus reaksi yang sudah ada
  await Rulzx.sendMessage(m.chat, { react: { text: '', key: m.key } });
  
  const msgii = await generateWAMessageFromContent(m.chat, {
    viewOnceMessageV2Extension: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: "Menampilkan Menu Button"
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [{
              body: proto.Message.InteractiveMessage.Body.fromObject({}),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({}),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `Hallo Kak`,
                hasMediaAttachment: true,
                ...(await prepareWAMessageMedia({ image: { url: 'https://img101.pixhost.to/images/162/547816215_skyzopedia.jpg' }}, { upload: Rulzx.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    "name": "single_select",
                    "buttonParamsJson": `{ "title": "ꜱᴇʟᴇᴄᴛ ᴀ ᴍᴇɴᴜ!", "sections": [{ "title": "# ꜱɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ", "highlight_label": "Rulzx Premium Script", "rows": [{ "header": "Allmenu", "title": "くそ ᴀʟʟᴍᴇɴᴜ", "id": ".rulzx" }, 
                    { "header": "create panel", "title": "くそ createpanel", "id": ".layanan" }]}]}`
                  },
                  {
                    "name": "cta_url",
                    "buttonParamsJson": `{\"display_text\":\"Wa Rulzx\",\"url\":\"https://whatsapp.com/\",\"merchant_url\":\"https://t.me/\"}`
                  }
                ]
              })
            }]
          })
        })
      }
    }
  }, { userJid: m.sender, quoted });

  await Rulzx.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id });
}
break
case "qc": {
    if (!text) return m.reply(`Contoh penggunaan: ${prefix}qc teksnya`);

    let ppuser;
    try {
        ppuser = await Rulzx.profilePictureUrl(m.sender, 'image');
    } catch (err) {
        ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg';
    }

    const json = {
        "type": "quote",
        "format": "png",
        "backgroundColor": "#000000",
        "width": 812,
        "height": 968,
        "scale": 2,
        "messages": [
            {
                "entities": [],
                "avatar": true,
                "from": {
                    "id": 1,
                    "name": m.pushName,
                    "photo": {
                        "url": ppuser
                    }
                },
                "text": text,
                "replyMessage": {}
            }
        ]
    };

    try {
        const response = await axios.post('https://bot.lyo.su/quote/generate', json, {
            headers: { 'Content-Type': 'application/json' }
        });

        const buffer = Buffer.from(response.data.result.image, 'base64');

        // Buat direktori jika belum ada
        const tempDir = path.join(__dirname, './database/sampah/');
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }

        // Path file sementara
        const tempPngPath = path.join(tempDir, `${m.sender}.png`);
        const tempWebPPath = path.join(tempDir, `${m.sender}.webp`);

        // Simpan gambar PNG sementara
        fs.writeFileSync(tempPngPath, buffer);

        // Konversi gambar ke WebP tanpa garis hitam
        await sharp(tempPngPath)
            .resize(512, 512, {
                fit: 'contain',           // Sesuaikan ukuran
                background: { r: 0, g: 0, b: 0, alpha: 0 } // Latar belakang transparan
            })
            .webp({ quality: 80 })        // Konversi ke WebP
            .toFile(tempWebPPath);

        // Kirim stiker
        await Rulzx.sendMessage(m.chat, { sticker: { url: tempWebPPath } }, { quoted: m });

        // Hapus file sementara
        fs.unlinkSync(tempPngPath);
        fs.unlinkSync(tempWebPPath);
    } catch (error) {
        console.error("Error saat memproses stiker:", error);
        m.reply("Gagal membuat stiker. Pastikan API tersedia atau coba lagi nanti.");
    }
}
break

case 'owner': {
    let list = [{
        displayName: 'Owner', 
        vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Owner\nTEL;TYPE=CELL:${global.owner}\nEND:VCARD`
    }];

    Rulzx.sendMessage(from, {
        contacts: {
            displayName: `1 Contact`,
            contacts: list
        }
    }, {
        quoted: m
    });
}
break
case 'delvps': {
    if (!isCreator) {
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Perintah ini hanya dapat digunakan oleh owner bot.',
        });
    }

    if (!text || isNaN(text)) {
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Anda harus memberikan ID droplet yang valid.\nGunakan format: .deletedroplet [ID_DROPLET]',
        });
    }

    const dropletId = text.trim();

    try {
        const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${global.digitalocean_apikey}`,
            },
        });

        if (response.status !== 204) {
            throw new Error('Gagal menghapus droplet. Periksa ID droplet Anda.');
        }

        const confirmationMessage = `✅ *DROPLET BERHASIL DIHAPUS*\n\n- *ID Droplet:* ${dropletId}\n\nDroplet telah dihapus dari akun DigitalOcean Anda.`;

        return Rulzx.sendMessage(m.chat, {
            image: { url: 'https://i.postimg.cc/BQ9pHFFc/WysModz.jpg' },
            caption: confirmationMessage,
        });
    } catch (error) {
        console.error('Error saat menghapus droplet:', error);
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Gagal menghapus droplet. Pastikan ID droplet benar dan API key valid.',
        });
    }
}
break
case 'monitoring': {
    if (!isCreator) {
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Perintah ini hanya dapat digunakan oleh owner bot.',
        });
    }

    if (!text || isNaN(text)) {
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Anda harus memberikan ID droplet yang valid.\nGunakan format: .monitoring [ID_DROPLET]',
        });
    }

    const dropletId = text.trim();

    try {
        const dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${global.digitalocean_apikey}`,
            },
        });

        if (!dropletResponse.ok) {
            throw new Error('Gagal mendapatkan data droplet. Periksa ID droplet Anda.');
        }

        const dropletData = await dropletResponse.json();
        const droplet = dropletData.droplet;

        const statsResponse = await fetch(`https://api.digitalocean.com/v2/monitoring/metrics/droplet/cpu?host_id=${dropletId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${global.digitalocean_apikey}`,
            },
        });

        const statsData = await statsResponse.json();

        if (!statsData || !statsData.data.result) {
            throw new Error('Gagal mendapatkan data monitoring untuk droplet ini.');
        }

        const cpuUsage = statsData.data.result[0]?.values.slice(-1)[0][1] || 'N/A'; // CPU usage in %
        const memoryUsage = 'N/A'; // Endpoint resmi untuk memori belum tersedia
        const ipAddress = droplet.networks.v4[0]?.ip_address || 'Tidak ada IP';

        const monitoringDetails = `📊 *MONITORING VPS*\n\n` +
            `- *Nama VPS*: ${droplet.name}\n` +
            `- *IP Address*: ${ipAddress}\n` +
            `- *Status*: ${droplet.status}\n\n` +
            `🔧 *Statistik Real-Time*:\n` +
            `- CPU Usage: ${cpuUsage}%\n` +
            `- Memory Usage: ${memoryUsage}\n` +
            `\n*Status*: ${cpuUsage > 80 ? '⚠️ Tinggi' : '✅ Normal'}`;

        return Rulzx.sendMessage(m.chat, {
            image: { url: 'https://pomf2.lain.la/f/6x4u9aqx.jpg' },
            caption: monitoringDetails,
        });
    } catch (error) {
        console.error('Error saat memantau droplet:', error);
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Gagal memantau droplet. Pastikan ID droplet benar dan API key valid.',
        });
    }
}
break
case 'billing': {
    if (!isCreator) {
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Perintah ini hanya dapat digunakan oleh owner bot.',
        });
    }

    try {
        const billingResponse = await fetch('https://api.digitalocean.com/v2/customers/my/balance', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${global.digitalocean_apikey}`,
            },
        });

        if (!billingResponse.ok) {
            throw new Error('Gagal mendapatkan informasi billing dari DigitalOcean.');
        }

        const billingData = await billingResponse.json();

        const monthToDateBalance = parseFloat(billingData.month_to_date_balance).toFixed(2);
        const accountBalance = parseFloat(billingData.account_balance).toFixed(2);
        const monthToDateUsage = parseFloat(billingData.month_to_date_usage).toFixed(2);

        const billingDetails = `📊 *BILLING OVERVIEW*\n\n` +
            `- *Total Pengeluaran Bulan Ini*: $${monthToDateBalance}\n` +
            `- *Saldo Akun*: $${accountBalance}\n` +
            `- *Penggunaan Bulan Ini*: $${monthToDateUsage}\n\n` +
            `🔗 *Dashboard*: https://cloud.digitalocean.com/account/billing`;

        return Rulzx.sendMessage(m.chat, {
            image: { url: 'https://pomf2.lain.la/f/6x4u9aqx.jpg' },
            caption: billingDetails,
        });
    } catch (error) {
        console.error('Error saat mengambil data billing:', error);
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Gagal mendapatkan informasi billing. Pastikan API key valid dan server DigitalOcean dapat diakses.',
        });
    }
}
break
case 'gptmode': {
    gptMode = true;
    m.reply('GPT Mode sudah berhasil diaktifkan. Semua pesan akan dikirim ke API GPT-4. Ketik .gptmodeoff untuk menonaktifkan.');
}
break

case 'gptmodeoff': {
    gptMode = false;
    m.reply('GPT Mode telah dinonaktifkan.');
}
break
case 'listvps': {
    if (!isCreator) {
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Perintah ini hanya dapat digunakan oleh owner bot.',
        });
    }

    try {
        const response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${global.digitalocean_apikey}`,
            },
        });

        if (!response.ok) {
            throw new Error('Gagal mendapatkan daftar droplet dari DigitalOcean.');
        }

        const data = await response.json();

        if (!data.droplets || data.droplets.length === 0) {
            return Rulzx.sendMessage(m.chat, {
                text: '🚫 Tidak ada droplet yang ditemukan di akun DigitalOcean Anda.',
            });
        }

        let dropletList = '*💻 DAFTAR DROPLET*\n\n';
        for (const droplet of data.droplets) {
            const ipAddress = droplet.networks.v4[0]?.ip_address || 'Tidak ada IP';
            dropletList += `- *ID:* ${droplet.id}\n`;
            dropletList += `  *Nama:* ${droplet.name}\n`;
            dropletList += `  *Status:* ${droplet.status}\n`;
            dropletList += `  *IP:* ${ipAddress}\n\n`;
        }

        return Rulzx.sendMessage(m.chat, {
            image: { url: 'https://i.postimg.cc/BQ9pHFFc/WysModz.jpg' },
            caption: dropletList,
        });
    } catch (error) {
        console.error('Error saat mengambil daftar droplet:', error);
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Gagal mendapatkan daftar droplet. Pastikan API key valid dan server DigitalOcean dapat diakses.',
        });
    }
}
break
case "get":
    if (!/^https?:\/\//.test(text)) {
        return reply("Awali *URL* dengan http:// atau https://");
    }

    try {
        const ajg = await fetch(text);
        
        // Cek batas ukuran konten (100 MB)
        if (parseInt(ajg.headers.get("content-length")) > 100 * 1024 * 1024) {
            throw `Content-Length: ${ajg.headers.get("content-length")}`;
        }

        const contentType = ajg.headers.get("content-type");

        // Jika konten berupa gambar
        if (contentType.startsWith("image/")) {
            return Rulzx.sendMessage(
                m.chat,
                { image: { url: text } },
                { quoted: m }
            );
        }
        
        // Jika konten berupa video
        if (contentType.startsWith("video/")) {
            return Rulzx.sendMessage(
                m.chat,
                { video: { url: text } },
                { quoted: m }
            );
        }
        
        // Jika konten berupa audio
        if (contentType.startsWith("audio/")) {
            return Rulzx.sendMessage(
                m.chat,
                { audio: { url: text } },
                { quoted: m }
            );
        }

        // Jika konten berupa teks atau kode, tentukan format file
        let alak = await ajg.buffer();
        let ext = "txt"; // Default ekstensi jika tidak dapat dikenali
        
        if (contentType.includes("json")) ext = "json";
        else if (contentType.includes("javascript")) ext = "js";
        else if (contentType.includes("html")) ext = "html";
        else if (contentType.includes("css")) ext = "css";

        const filePath = path.join(__dirname, 'lib', `get-data.${ext}`);
        fs.writeFileSync(filePath, alak); // Simpan ke file sementara di folder lib

        // Kirim file sebagai dokumen
        await Rulzx.sendMessage(
            m.chat,
            { document: { url: filePath }, mimetype: contentType, fileName: `get-data.${ext}` },
            { quoted: m }
        );

        // Hapus file setelah dikirim
        fs.unlinkSync(filePath);
    } catch (e) {
        console.error(e);
        reply("Gagal mengambil data atau terjadi kesalahan.");
    }
    break
case  'pin': {
  if (!text) return reply(`Example: .pin Nakano Ninoo`);
  await reply("Mohon tunggu kak");

  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent({
      image: {
        url
      }
    }, {
      upload: Rulzx.waUploadToServer
    });
    return imageMessage;
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  let push = [];
  let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
  let res = data.resource_response.data.results.map(v => v.images.orig.url);

  shuffleArray(res);
  let ult = res.splice(0, 5); 
  let i = 1;

  for (let lucuy of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Image ke - ${i++}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: global.namabot
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: 'Hasil.',
        hasMediaAttachment: true,
        imageMessage: await createImage(lucuy)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            "name": "cta_url",
            "buttonParamsJson": `{"display_text":"Source","url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}","merchant_url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}"}`
          }
        ]
      })
    });
  }

  let bot = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: "Done"
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: `Search: ${text} | Nama: ${pushname}`
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [
              ...push
            ]
          })
        })
      }
    }
  }, {});

  await Rulzx.relayMessage(m.chat, bot.message, {
    messageId: bot.key.id
  });
  
}
break
case 'trackip':
{
if (!text) return m.reply(`*Example:* ${prefix + command} 112.90.150.204`);
try {
let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

const formatIPInfo = (info) => {
 return `
*IP Information*
• IP: ${info.ip || 'N/A'}
• Success: ${info.success || 'N/A'}
• Type: ${info.type || 'N/A'}
• Continent: ${info.continent || 'N/A'}
• Continent Code: ${info.continent_code || 'N/A'}
• Country: ${info.country || 'N/A'}
• Country Code: ${info.country_code || 'N/A'}
• Region: ${info.region || 'N/A'}
• Region Code: ${info.region_code || 'N/A'}
• City: ${info.city || 'N/A'}
• Latitude: ${info.latitude || 'N/A'}
• Longitude: ${info.longitude || 'N/A'}
• Is EU: ${info.is_eu ? 'Yes' : 'No'}
• Postal: ${info.postal || 'N/A'}
• Calling Code: ${info.calling_code || 'N/A'}
• Capital: ${info.capital || 'N/A'}
• Borders: ${info.borders || 'N/A'}
• Flag:
 - Image: ${info.flag?.img || 'N/A'}
 - Emoji: ${info.flag?.emoji || 'N/A'}
 - Emoji Unicode: ${info.flag?.emoji_unicode || 'N/A'}
• Connection:
 - ASN: ${info.connection?.asn || 'N/A'}
 - Organization: ${info.connection?.org || 'N/A'}
 - ISP: ${info.connection?.isp || 'N/A'}
 - Domain: ${info.connection?.domain || 'N/A'}
• Timezone:
 - ID: ${info.timezone?.id || 'N/A'}
 - Abbreviation: ${info.timezone?.abbr || 'N/A'}
 - Is DST: ${info.timezone?.is_dst ? 'Yes' : 'No'}
 - Offset: ${info.timezone?.offset || 'N/A'}
 - UTC: ${info.timezone?.utc || 'N/A'}
 - Current Time: ${info.timezone?.current_time || 'N/A'}
`;
};
 
if (!res.success) throw new Error(`IP ${text} not found!`);
await Rulzx.sendMessage(m.chat, { location: { degreesLatitude: res.latitude, degreesLongitude: res.longitude } }, { ephemeralExpiration: 604800 });
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
await delay(2000);
m.reply(formatIPInfo(res)); 
} catch (e) { 
m.reply(`Error: Unable to retrieve data for IP ${text}`);
}
}
break
case "lr": {
  if (!text) return reply("Pesan Salah, masukkan perintah dengan format: .lr ram");

  try {
    // Opsi RAM dan konfigurasi Linode
    const ramOptions = {
      '1gb': { size: 'g6-nanode-1' },
      '2gb': { size: 'g6-standard-1' },
      '4gb': { size: 'g6-standard-2' },
      '8gb': { size: 'g6-standard-4' },
      '16gb': { size: 'g6-standard-6' },
      '24gb': { size: 'g6-highmem-1' }
    };

    const selectedRam = text.trim().toLowerCase();
    if (!ramOptions[selectedRam]) {
      return reply("Pilihan tidak valid. Gunakan salah satu dari: 1gb, 2gb, 4gb, 8gb, 16gb, atau 24gb.");
    }

    const { size } = ramOptions[selectedRam];

    reply(`Membuat VPS dengan spesifikasi ${selectedRam.toUpperCase()}. Mohon tunggu...`);

    // Fungsi untuk menghasilkan nama acak
    const generateRandomName = () => {
      const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      let result = '';
      for (let i = 0; i < 8; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return result;
    };

    // Data konfigurasi VPS
    const linodeData = {
      label: `vps-${generateRandomName()}`,
      region: 'ap-south',
      type: size,
      image: 'linode/ubuntu20.04',
      root_pass: '#CreatedByRulz12@',
      backups_enabled: false
    };

    // Request ke API Linode
    const response = await fetch('https://api.linode.com/v4/linode/instances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer 8dc44d7b87295745275e5577083bc2d4f38bf84e23f117bb892148c7fff7bd20`
      },
      body: JSON.stringify(linodeData)
    });

    const responseData = await response.json();
    if (!response.ok) {
      throw new Error(`Gagal membuat VPS: ${responseData.errors?.[0]?.reason || 'Unknown error'}`);
    }

    const linodeId = responseData.id;
    reply("Tunggu sebentar, VPS sedang dibuat...");

    // Tunggu proses pembuatan VPS
    await new Promise(resolve => setTimeout(resolve, 60000));

    const linodeResponse = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer 8dc44d7b87295745275e5577083bc2d4f38bf84e23f117bb892148c7fff7bd20`
      }
    });

    const linodeInfo = await linodeResponse.json();
    const ipAddress = linodeInfo.ipv4[0];

    let messageText = `VPS berhasil dibuat!

- ID: ${linodeId}
- IP VPS: ${ipAddress}
- Password: ${linodeData.root_pass}\n`;
    await Rulzx.sendMessage(m.chat, { text: messageText });
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan: ${err.message}`);
  }
}
break
        

case 'listcase': {
if (!isCreator) return reply('khusus owner')
let { listCase } = require('./lib/scrapelistCase.js')
m.reply(listCase())
}
break

default:
if (body.startsWith('>')) {
if(!isCreator) return reply(`*[ System Notice ]* cannot access`)
try {
let evaled = await eval(body.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
reply(String(err))
}
}
if (body.startsWith('$')){
if(!isCreator) return reply(`*[ System Notice ]* cannot access`)
qur = body.slice(2)
exec(qur, (err, stdout) => {
if (err) return reply795(`${err}`)
if (stdout) {
reply(stdout)
}
})
}
if (body.startsWith('<')) {
if(!isCreator) return reply(`*[ System Notice ]* cannot access`)
try {
return m.reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
m.reply(e)
}
}

}
} catch (err) {
m.reply(util.format(err))
}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
