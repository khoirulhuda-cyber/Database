module.exports = async (Rulzx, m, store) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '' //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const wib = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("DD MMMM YYYY HH:mm:ss z");
const archiver = require('archiver')
const text = q = args.join(" ")
const botNumber = await Rulzx.decodeJid(Rulzx.user.id)
const isOwner = m.sender == owner+"@s.whatsapp.net" ? true : m.sender == botNumber ? true : false
const isCreator = m.sender == owner+"@s.whatsapp.net" ? true : m.sender == botNumber ? true : false
const isGroup = m.chat.endsWith('@g.us')
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await Rulzx.groupMetadata(m.key.remoteJid) : {}
let participant_bot = (isGroup ? groupMetadata.participants.find((v) => v.id == m.botNumber) : {}) || {}
let participant_sender = (isGroup ? groupMetadata.participants.find((v) => v.id == m.sender) : {}) || {}
const isBotAdmin = participant_bot?.admin !== null ? true : false
const isAdmin = participant_sender?.admin !== null ? true : false
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson } = require('./data/function.js')
const { toAudio, toPTT, toVideo, ffmpeg } = require("./data/converter.js")
const antilink = JSON.parse(fs.readFileSync('./data/database/antilink.json'))
const antilink2 = JSON.parse(fs.readFileSync('./data/database/antilink2.json'))
const contacts = JSON.parse(fs.readFileSync("./data/database/contacts.json"))
const { teksbug1 } = require("./data/database/virtex.js")
const { teksbug2 } = require("./data/database/delay.js")


if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(namabot), color(`[ PESAN ]`, `blue`), color(`FROM`, `blue`), color(`${senderNumber}`, `blue`), color(`Text :`, `blue`), color(`${cmd}`, `white`))
}

if (isGroup && antilink.includes(m.chat) && isBotAdmin) {
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await Rulzx.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Rulzx.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Kamu Akan Saya Keluarkan Dari Grup Ini Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://j.top4top.io/p_32559q22m2.jpg", title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await Rulzx.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await Rulzx.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}}

if (isGroup && antilink2.includes(m.chat) && isBotAdmin) {
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await Rulzx.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Rulzx.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Pesan Kamu Saya Hapus Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://j.top4top.io/p_32559q22m2.jpg", title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await Rulzx.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
}
}}

const qdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: 'Whatsapp Bot By Rulzx official',jpegThumbnail: ""}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Whatsapp Jpm By Rulzx officiall`,jpegThumbnail: ""}}}

const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Wa Bot By Rulzx officiall`,jpegThumbnail: ""}}}

let example = (teks) => {
return `\n*Contoh Penggunaan :*\nketik *${cmd}* ${teks}\n`
}

var resize = async (image, width, height) => {
let oyy = await Jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
return kiyomasa
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

const qbug = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {listResponseMessage: {title: `Rulzx official`
}}}

const MessageBug = async (target) => {
return Rulzx.sendMessage(target, {document: fs.readFileSync("./data/kosong.js"), mimetype: "😄😇😂🔥", fileName: "Paket.zip", fileLength: 99999999999, caption: `key.com${teksbug2}`}, {quoted: qbug})
}


switch (command) {
case 'backup': {
    if (!isCreator) {
        return Rulzx.sendMessage(m.chat, {
            text: '❌ Perintah ini hanya dapat digunakan oleh owner bot.',
        });
    }

    try {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const zipFileName = `backup_${timestamp}.zip`;
        const zipFilePath = path.join(__dirname, zipFileName);

        // Membuat file ZIP
        const output = fs.createWriteStream(zipFilePath);
        const archive = archiver('zip', { zlib: { level: 9 } });

        output.on('close', async () => {
            console.log(`✅ Arsip ZIP berhasil dibuat (${archive.pointer()} bytes)`);

            // Konfigurasi GitHub
            const owner = global.githubOwner;
            const repo = global.githubRepo;
            const pathInRepo = `backups/${zipFileName}`;
            const branch = global.githubBranch || 'main';
            const githubToken = global.githubToken;

            const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${pathInRepo}`;
            const headers = {
                'Content-Type': 'application/json',
                Authorization: `token ${githubToken}`,
                Accept: 'application/vnd.github.v3+json'
            };

            // Baca file ZIP dan encode ke base64
            const fileData = fs.readFileSync(zipFilePath);
            const base64Content = fileData.toString('base64');

            // Persiapkan payload untuk GitHub
            const payload = {
                message: `Backup otomatis: ${zipFileName}`,
                committer: {
                    name: global.githubCommitterName || 'WhatsApp Bot',
                    email: global.githubCommitterEmail || 'bot@example.com'
                },
                content: base64Content,
                branch: branch
            };

            // Unggah ke GitHub
            const response = await fetch(apiUrl, {
                method: 'PUT',
                headers,
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Gagal mengunggah backup ke GitHub.');
            }

            // Hapus file lokal setelah berhasil diunggah
            fs.unlinkSync(zipFilePath);

            return Rulzx.sendMessage(m.chat, {
                text: `✅ Backup berhasil diunggah ke GitHub!\n🔹 File: ${zipFileName}`,
            });
        });

        archive.on('error', (err) => {
            throw err;
        });

        archive.pipe(output);

        // Tambahkan folder yang ingin dibackup
        const foldersToBackup = ['data', 'media', 'session'];
        foldersToBackup.forEach(folder => {
            const folderPath = path.join(__dirname, folder);
            if (fs.existsSync(folderPath)) {
                archive.directory(folderPath, folder);
            }
        });

        // Tambahkan file yang ingin dibackup
        const filesToBackup = [
            'main.js',
            'settings.js',
            'thumbnail.jpg',
            'Rulzx.js',
            'package-lock.json',
            'package.json'
        ];
        filesToBackup.forEach(file => {
            const filePath = path.join(__dirname, file);
            if (fs.existsSync(filePath)) {
                archive.file(filePath, { name: file });
            }
        });

        archive.finalize();
    } catch (error) {
        console.error('❌ Error saat melakukan backup:', error);
        return Rulzx.sendMessage(m.chat, {
            text: `❌ Gagal melakukan backup.\n🛠 Error: ${error.message}`,
        });
    }
}
break
case "menu": {
const textnya = `*乂 Information - Bot*
  • Botname : *${global.namabot}*
  • Version : *VERSI 1.1*
  • Mode : *${Rulzx.public ? "Public": "Self"}*
  • Creator : @${global.owner}
  • Runtime Bot : *${runtime(process.uptime())}*
 ▬▭▬▭▬▭▬▭▬▭▬▭▬
╭──• ❰ *𝙿𝚞𝚜𝚑 𝙺𝚘𝚗𝚝𝚊𝚔 𝙼𝚎𝚗𝚞* ❱
║◦ .𝙥𝙪𝙨𝙝𝙠𝙤𝙣𝙩𝙖𝙠
║◦ .𝙥𝙪𝙨𝙝𝙠𝙤𝙣𝙩𝙖𝙠1
║◦ .𝙥𝙪𝙨𝙝𝙠𝙤𝙣𝙩𝙖𝙠2
║◦ .𝙨𝙖𝙫𝙚𝙠𝙤𝙣𝙩𝙖𝙠
║◦ .𝙨𝙖𝙫𝙚𝙠𝙤𝙣𝙩𝙖𝙠2
║◦ .𝙥𝙪𝙗𝙡𝙞𝙘
║◦ .𝙨𝙚𝙡𝙛
║◦ .𝙡𝙞𝙨𝙩𝙜𝙘
╰⟢
╭──• ❰ *𝚂𝚝𝚘𝚛𝚎 𝙼𝚎𝚗𝚞* ❱
║◦ .𝙥𝙧𝙤𝙙𝙪𝙠
║◦ .𝙙𝙤𝙣𝙚
║◦ .𝙥𝙧𝙤𝙨𝙚𝙨
║◦ .𝙥𝙖𝙮𝙢𝙚𝙣𝙩
║◦ .𝙟𝙥𝙢𝙩𝙚𝙨𝙩𝙞
╰⟢
╭──• ❰ *𝙹𝚙𝚖 𝙼𝚎𝚗𝚞* ❱
║◦ .𝙞𝙙𝙜𝙘
║◦ .𝙟𝙥𝙢
║◦ .𝙟𝙥𝙢2
║◦ .𝙟𝙥𝙢𝙝𝙞𝙙𝙚𝙩𝙖𝙜
║◦ .𝙟𝙥𝙢𝙥𝙤𝙡𝙡
║◦ .𝙨𝙩𝙖𝙧𝙩𝙟𝙥𝙢
╰⟢
╭──• ❰ *𝚁𝚊𝚗𝚍𝚘𝚖 𝙼𝚎𝚗𝚞* ❱
║◦ .𝙥𝙡𝙖𝙮
║◦ .𝙢𝙚𝙙𝙞𝙖𝙛𝙞𝙧𝙚
║◦ .𝙩𝙞𝙠𝙩𝙤𝙠
║◦ .𝙩𝙩𝙨
║◦ .𝙦𝙘
║◦ .𝙩𝙤𝙪𝙧𝙡
║◦ .𝙩𝙤𝙪𝙧𝙡2
║◦ .𝙗𝙧𝙖𝙩
║◦ .𝙨𝙩𝙞𝙘𝙠𝙚𝙧
║◦ .𝙨𝙩𝙞𝙘𝙠𝙚𝙧𝙬𝙢
║◦ .𝙘𝙚𝙠𝙞𝙙𝙘𝙝
║◦ .𝙜𝙚𝙩𝙘𝙖𝙨𝙚
║◦ .𝙥𝙞𝙣𝙩𝙚𝙧𝙚𝙨𝙩
╰⟢

> Sc-NewPushkontak-Rulzx official
`
Rulzx.sendMessage(m.chat, {text: textnya, contextInfo: {mentionedJid: [m.sender], externalAdReply: {showAdAttribution: true, thumbnailUrl: global.image, title: `© ${global.namabot}`, body: null, sourceUrl: linkgc, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: qdoc})
}
break
case "pushkontak": {
if (!isOwner) return m.reply(msg.owner)
if (!isGroup) return m.reply(msg.group)
if (!text) return m.reply(example("pesannya"))
var teks = text
const halls = await groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
m.reply(`Memproses Mengirim Pesan Ke *${halls.length}* Member Grup`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./data/database/contacts.json', JSON.stringify(contacts))
await Rulzx.sendMessage(mem, {text: teks}, {quoted: qloc2})
await sleep(global.delaypushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./data/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await Rulzx.sendMessage(m.sender, { document: fs.readFileSync("./data/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./data/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./data/database/contacts.vcf", "")
}}
break
case "listgc": case "cekid": case"listgrup": {
let gcall = Object.values(await Rulzx.groupFetchAllParticipating().catch(_=> null))
let listgc = `*｢ 𝙻𝙸𝚂𝚃 𝙰𝙻𝙻 𝙲𝙷𝙰𝚃 𝙶𝚁𝙾𝚄𝙿 ｣*\n\n`
await gcall.forEach((u, i) => {
listgc += `*• ɴᴀᴍᴀ :* ${u.subject}\n*• ɪᴅ :* ${u.id}\n*• ᴛᴏᴛᴀʟ ᴍᴇᴍʙᴇʀ :* ${u.participants.length} ᴍᴇᴍʙᴇʀ\n*• sᴛᴀᴛᴜs ɢʀᴜᴘ :* ${u.announce == true ? "ᴛᴇʀᴛᴜᴛᴜᴘ" : "ᴛᴇʀʙᴜᴋᴀ"}\n*• ᴘᴇᴍʙᴜᴀᴛ :* ${u.owner ? u.owner.split('@')[0] : 'sᴜᴅᴀʜ ᴋᴇʟᴜᴀʀ'}\n\n`
})
m.reply(listgc)
}
break

case "startjpm": {
if (!isOwner) return m.reply(msg.owner)
var teksnya = await fs.readFileSync("./data/database/teksjpm.js").toString()
if (teksnya.length < 1) return m.reply("Teks Jpm Tidak Ditemukan, Silahlan Isi/Edit Teks Jpm Didalam Folder data/database")
var teks = `${teksnya}`
let total = 0
let getGroups = await Rulzx.groupFetchAllParticipating()
let usergc = await Object.keys(getGroups)
m.reply(`Memproses Mengirim Pesan *Text* Ke *${usergc.length}* Grup`)
for (let jid of usergc) {
try {
await Rulzx.sendMessage(jid, {text: teks}, {quoted: qloc})
total += 1
} catch {}
await sleep(4000)
}
m.reply(`Berhasil Mengirim Pesan Ke *${total} Grup*`)
}
break
break
case "jpm": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return m.reply(example("teksnya atau reply teks"))
var teks = m.quoted ? m.quoted.text : text
let total = 0
let getGroups = await Rulzx.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
m.reply(`Memproses Mengirim Pesan *Text* Ke *${usergc.length}* Grup`)
for (let jid of usergc) {
try {
await Rulzx.sendMessage(jid, {text: teks}, {quoted: qloc})
total += 1
} catch {}
await sleep(global.delayjpm)
}
m.reply(`Berhasil Mengirim Pesan Ke *${total} Grup*`)
}
break
case "ytplay": case "play": {
if (!text) return m.reply(example('Dj tiktok'))
m.reply(msg.wait)
const { pipeline } = require('stream')
const { promisify } = require('util')
const streamPipeline = promisify(pipeline)
try {
let search = await yts(text)
let vid = search.videos[0]
let { title, thumbnail: thumb, timestamp, author, url } = vid
const audioStream = ytdl(url, {
filter: 'audioonly',
quality: 'highestaudio'})
let acak = await getRandom(".mp3")
const writableStream = fs.createWriteStream(`./data/tmp/${acak}`)
await streamPipeline(audioStream, writableStream)
await Rulzx.sendMessage(m.chat, {audio: fs.readFileSync(`./data/tmp/${acak}`), mimetype: 'audio/mpeg', contextInfo: {externalAdReply: {thumbnailUrl: thumb, title: title, body: "Duration : "+timestamp+" | "+"Author : "+author.name, sourceUrl: url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
fs.unlinkSync(`./data/tmp/${acak}`)
} catch (e) {
return m.reply(e.toString())
}
}
break
case "ytmp3": case "ytdl": {
if (!text) return m.reply(example('linknya'))
if (!text.includes("https")) return m.reply("Link Tautan Tidak Valid!")
if (!text.includes("youtube.com")) return m.reply("Link Tautan Tidak Valid!")
m.reply(msg.wait)
var judul = `./data/tmp/${getRandom(".mp3")}`
const videoURL = text
const options = {
  quality: 'highestaudio',
  filter: 'audioonly'
}
ytdl(videoURL, options)
  .pipe(fs.createWriteStream(judul))
  .on('finish', async function () {
var ai = await yts(text)
var vid = ai.videos[0]
try {
let { title, thumbnail: thumb, timestamp, author, url } = vid
await Rulzx.sendMessage(m.chat, {audio: fs.readFileSync(judul), mimetype: 'audio/mpeg', contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: thumb, title: title, body: `Duration : ${timestamp} | Author : ${author.name}`, sourceUrl: null,  renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
await fs.unlinkSync(judul)
} catch (e) {
await Rulzx.sendMessage(m.chat, {audio: fs.readFileSync(judul), mimetype: 'audio/mpeg'}, {quoted: m})
await fs.unlinkSync(judul)
}
}).on('error', (err) => {
return m.reply(err.toString())
})}
break


//================================================================================

case "brat": {
if (!text) return m.reply(example('teksnya'))
let res = await getBuffer(`https://api.zenkey.my.id/api/maker/brat?text=${text}&apikey=zenkey`)
await Rulzx.sendStimg(m.chat, res, m, {packname: global.packname})
}
break

//================================================================================

case "qc": {
if (!text) return m.reply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
var ppuser
try {
ppuser = await Rulzx.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": "#000000",
  "width": 812,
  "height": 968,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = "./data/tmp/"+m.sender+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return m.reply("Error")
await Rulzx.sendStimg(m.chat, tempnya, m, {packname: global.packname})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break
case "sticker": case "stiker": case "sgif": case "s": {
if (!/image|video/.test(mime)) return m.reply(example("dengan mengirim foto/vidio"))
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
}
m.reply(msg.wait)
var media = await Rulzx.downloadAndSaveMediaMessage(qmsg)
await Rulzx.sendStimg(m.chat, media, m, {packname: "Whatsapp Bot 2025"})
await fs.unlinkSync(media)
}
break


//================================================================================

case "done": {
if (!isOwner) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await Rulzx.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Transaksi Done ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break

//================================================================================

case "proses": {
if (!isOwner) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await Rulzx.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Dana Masuk ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break

//================================================================================

case "public": {
if (!isOwner) return m.reply(msg.owner)
Rulzx.public = true
m.reply("Berhasil mengganti mode bot menjadi *Public*")
}
break
case "self": {
if (!isOwner) return m.reply(msg.owner)
Rulzx.public = false
m.reply("Berhasil Menganti mode menjadi *Seleb ☕*")
}
break

//================================================================================

case "getcase": {
if (!isOwner) return Reply(mess.owner)
if (!text) return m.reply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./case.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

//================================================================================

case "tourl": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await Rulzx.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'Rulzxofficialpng');

let teks = directLink.toString()
await Rulzx.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//================================================================================

default:
if (budy.startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return Rulzx.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return Rulzx.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

if (budy.startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
Rulzx.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
Rulzx.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return Rulzx.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return Rulzx.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

}} catch (e) {
console.log(e)
Rulzx.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})