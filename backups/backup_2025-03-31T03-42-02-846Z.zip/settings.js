require("./data/module.js")

//========== Setting Data ==========//
global.owner = '6281542692178'
global.githubOwner = 'khoirulhuda-cyber';
global.githubRepo = 'Database';
global.githubBranch = 'main';
global.githubToken = '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';
global.namaOwner = "Rulzx official"
global.packname = 'Bot WhatsApp'
global.namabot = 'NewBot-Rulzx'
global.idsaluran = "-"
global.linkSaluran = "https://whatsapp.com/channel/0029VauencUDTkKAWlcfy606"
global.linkgc = '-'
global.linkGrup = "https://chat.whatsapp.com/Cu6sxgN9DFCAVgA0npWC60"



//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 5500
global.delayjpm = 5500

//========= Setting Url Foto =========//
global.image = "https://img101.pixhost.to/images/302/550250430_Rulzxofficialpng.jpg"

//========= Setting Payment =========//
global.dana = "081542692178"
global.gopay = "081542692178"
global.ovo = false
global.qris = "https://img101.pixhost.to/images/302/550250649_Rulzxofficialpng.jpg"

global.msg = {
"error": "Error terjasi kesalahan",
"done": "Berhasil mengambil data ", 
"wait": "Wait bang lagi proses ☕", 
"group": "Fitur Ini Hanya Untuk Didalam Grup", 
"private": "Fitur Ini Hanya Untuk Didalam Private Chat", 
"admin": "Fitur Ini Hanya Untuk Admin Grup", 
"adminbot": "Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin", 
"owner": "Fitur Ini Hanya Untuk Owner Bot", 
"developer": "Fitur Ini Hanya Untuk Developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})