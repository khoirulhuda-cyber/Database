global.prefa = ['/','!','.',',','🐤','🗿']
global.owner = "6281542692178"
global.error = "6281542692178@s.whatsapp.net"
global.wang = "6281542692178@s.whatsapp.net"
global.ownNumb = "6281542692178"
global.namebot = "Rulzx Premium"
global.namaowner = "Rulzx"
global.wm = "Rulzx"
global.idsal = "@newsletter"
global.domain = "https://publicdenzx.rulzcloud.systems"
global.apikey = "ptlc_ppl1iJgGsf2yiNS81GQHpb2T9akjCznSYHhYINl7cXk"
global.digitalocean_apikey = "dop_v1_f35f8b33c15b02f164ff958d8ff8af2b41f4e5f7d3fd0cbcc4c3320204ac0ac3"
global.digitalocean_apikeyv2 = "dop_v1_7a54b9de96f3d5988909701017b6e05b519f577889ff57f9983afe0b5928e2ce"
global.githubOwner = 'khoirulhuda-cyber';
global.githubRepo = 'Database';
global.githubBranch = 'main';
global.githubToken = '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';
global.merchant = ""
global.codeqr = ""
global.keyorkut = ""
global.ram1 = '20000'
global.ram2 = '30000'
global.ram4 = '40000'
global.ram8 = '50000'
global.thumbyt = 'https://pomf2.lain.la/f/klbue7b.jpg'
global.thumbmen = 'https://pomf2.lain.la/f/klbue7b.jpg'

global.mess = {
    success: 'Success ✓',
    done: 'Success ✓',
    admin: 'Fitur Khusus Admin Group!',
    botAdmin: 'botz Harus Menjadi Admin Terlebih Dahulu!',
    owner: 'Fitur Khusus Owner',
    group: 'Fitur Khusus Group Chat',
    private: 'Fitur Khusus Private Chat!',
    bot: 'Fitur Khusus Nomor Owner',
    wait: 'Sabar ya sedang proses',
    band: 'kamu telah di banned oleh owner\nminta unbanned ke owner agar bisa menggunakan fitur bot lagi',
    notregist: 'Kamu belum terdaftar di database bot silahkan daftar terlebih dahulu',
    premium: 'Kamu Bukan User Premium, Beli Sana Ke Owner Bot',
    error: "*Maaf fitur sedang Error*",
    endLimit: 'Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Pukul 00:00 WIB.',
}
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})